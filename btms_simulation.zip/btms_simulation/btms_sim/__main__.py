"""Enables ``python -m btms_sim``."""

import sys

from .main import main

sys.exit(main())
