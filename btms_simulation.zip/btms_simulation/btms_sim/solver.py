"""3-D transient thermal solver -- explicit finite-difference enthalpy method.

Governing equation (heat generation in the cell, conduction everywhere,
phase change in the PCM handled through the enthalpy formulation):

    rho * dH/dt = div( k grad T ) + q'''        with  H = H(T)

Discretisation
--------------
* Structured cylindrical (r, theta, z) grid (see geometry.py).
* Nodal enthalpy update (explicit Euler), energy-exact:

      H_new = H_old + dt/V * [ sum_faces G (T_nb - T_node)
                               + sum_bnd h_eff A (T_amb - T_node)
                               + q''' V ]

* Piecewise-linear enthalpy-temperature function per node

      T <= T_sol :  H = rho cp_s (T - T_ref)
      mushy zone :  H = rho cp_s (T - T_ref) + rho L (T - T_sol)/(T_liq - T_sol)
      T >= T_liq :  H = rho cp_s (T - T_ref) + rho L
                     + rho cp_l (T - T_liq)

  which is inverted exactly each step (Voller 1987; Voller & Swaminathan
  1991).  Because the inversion is the exact inverse of the forward map,
  the scheme conserves energy to machine precision (verified by the
  pytest suite).

* Face conductances use the series-resistance (harmonic mean) form so that
  material interfaces (cell/PCM, PCM/enclosure) are treated correctly.
* PCM conductivity is updated every step from the local melt fraction:
  k_pcm(f) = k_s + f (k_liq,eff - k_s), with k_liq,eff =
  k_liquid * k_liquid_enhancement (an enhanced-liquid-conductivity
  surrogate for buoyancy-driven convection inside the melt, a standard
  practical correction for pure-conduction PCM models).

Boundary conditions
-------------------
* Robin (convection + linearized radiation) on all exterior faces:
      h_eff = 1 / ( 1/(h_conv + h_rad) + R_wall )
  - h_conv: Churchill-Chu correlation for a horizontal cylinder
    (film-temperature air properties), or a user-set constant.
  - h_rad = eps sigma (T_s + T_a)(T_s^2 + T_a^2), evaluated per face.
  - R_wall: thin-walled enclosure conduction resistance (PCM cases only,
    Biot number << 0.1 justifies not meshing the wall).
* Axis symmetry at r = 0 (zero-flux faces of the wedge cells have zero area
  by construction).
* End caps convect like the barrel (terminals); they can be switched to
  adiabatic via a per-case option ``insulated_ends`` for verification runs.

Time stepping
-------------
Adaptive explicit stepping at ``dt = cfl * dt_stable`` with

    dt_stable = min_nodes ( rho cp_min V / sum(G_faces) )

(the enthalpy addition in the mushy zone only *increases* effective heat
capacity, so using cp_min is conservative), clamped by dt_max, a per-step
growth limit and the next output event.
"""

from __future__ import annotations

import time as _time
from dataclasses import dataclass, field

import numpy as np
import pandas as pd
from scipy import constants

from .battery import BatteryModel
from .geometry import MAT_CELL, MAT_PCM, Grid, build_grid
from .properties import PCMProperties, build_pcm_properties

__all__ = ["ThermalSolver", "CaseResult"]

SIGMA = constants.Stefan_Boltzmann      # W/m2-K4
G_ACC = constants.g                     # m/s2

# Dry air at 1 atm -- linear interpolation table (Incropera, Table A.4)
_AIR_T = np.array([280.0, 300.0, 320.0, 340.0, 360.0, 380.0, 400.0])
_AIR_K = np.array([0.0246, 0.0263, 0.0278, 0.0293, 0.0307, 0.0321, 0.0335])
_AIR_NU = np.array([1.382e-5, 1.593e-5, 1.798e-5, 2.021e-5, 2.255e-5, 2.500e-5, 2.757e-5])
_AIR_PR = np.array([0.713, 0.707, 0.702, 0.697, 0.692, 0.688, 0.684])


def air_properties(T_film_K: float) -> tuple[float, float, float, float]:
    """Return (k, nu, Pr, alpha) of dry air at film temperature."""
    k = float(np.interp(T_film_K, _AIR_T, _AIR_K))
    nu = float(np.interp(T_film_K, _AIR_T, _AIR_NU))
    pr = float(np.interp(T_film_K, _AIR_T, _AIR_PR))
    return k, nu, pr, nu / pr


def h_churchill_chu(T_s_K: float, T_a_K: float, D: float) -> float:
    """Natural-convection coefficient for a long horizontal cylinder
    (Churchill & Chu 1975), valid for the laminar-to-turbulent Ra range
    relevant to battery-scale geometry."""
    dT = abs(T_s_K - T_a_K)
    if dT < 1e-6 or D <= 0.0:
        return 0.5
    T_f = 0.5 * (T_s_K + T_a_K)
    k_air, nu, pr, alpha = air_properties(T_f)
    Ra = G_ACC * (1.0 / T_f) * dT * D**3 / (nu * alpha)
    nu_nusselt = (0.60 + 0.387 * Ra ** (1.0 / 6.0)
                  / (1.0 + (0.559 / pr) ** (9.0 / 16.0)) ** (8.0 / 27.0)) ** 2
    return max(nu_nusselt * k_air / D, 0.5)


# --------------------------------------------------------------------------- #
@dataclass
class CaseResult:
    """Everything produced by one simulation case."""
    case_id: str
    label: str
    pcm_props: PCMProperties | None
    grid_summary: dict
    timeseries: pd.DataFrame
    snapshots: dict[float, dict]          # t -> {'T_rz': (nr,nz), 'f_rz': (nr,nz)}
    peaks: dict
    energy: dict
    run_seconds: float

    @property
    def has_pcm(self) -> bool:
        return self.pcm_props is not None


# --------------------------------------------------------------------------- #
class ThermalSolver:
    """Explicit enthalpy-method FDM solver for one configuration."""

    def __init__(self, cfg: dict, case: dict):
        self.cfg = cfg
        self.case = case
        self.case_id = case["id"]

        pcm_type = case["pcm_type"]
        self.has_pcm = pcm_type != "none"
        self.pcm: PCMProperties | None = build_pcm_properties(cfg, pcm_type)
        self.grid: Grid = build_grid(cfg, self.has_pcm)

        op = cfg["operating"]
        num = cfg["numerics"]
        rt = cfg["runtime"]

        self.T_amb_C = float(op["ambient_C"])
        self.T_amb_K = self.T_amb_C + 273.15
        self.T_init_C = float(op["initial_C"])
        self.eps = float(op["emissivity"])
        self.h_mode = op["h_mode"]
        self.h_const = float(op["h_constant_W_m2K"])
        self.k_enh = float(op["k_liquid_enhancement"])

        self.cfl = float(num["cfl"])
        self.dt_min = float(num["dt_min_s"])
        self.dt_max = float(num["dt_max_s"])
        self.dt_growth = float(num["dt_growth"])

        self.t_end = float(rt["discharge_s"]) + float(rt["rest_s"])
        self.t_discharge = float(rt["discharge_s"])
        self.sample_every = float(rt["sample_every_s"])
        self.snapshot_times = [float(x) for x in rt.get("snapshot_times_s", [])]

        self.insulated_ends = bool(case.get("options", {}).get("insulated_ends", False))

        self.battery = BatteryModel(
            capacity_Ah=cfg["cell"]["capacity_Ah"],
            c_rate=op["c_rate"],
            r0_ref_ohm=cfg["battery"]["r0_ref_ohm"],
            soc_points=cfg["battery"]["soc_points"],
            r_mult_points=cfg["battery"]["r_multiplier_points"],
            du_dt_points=cfg["battery"]["du_dt_points_V_K"],
            discharge_s=self.t_discharge,
            q_constant_W=op.get("q_constant_W"),
        )

        self._build_node_arrays()
        self._select_boundaries()

    # ------------------------------------------------------------------ #
    #  setup helpers
    # ------------------------------------------------------------------ #
    def _build_node_arrays(self) -> None:
        g = self.grid
        N = g.nr * g.n_theta * g.nz
        self.N = N
        mat = np.repeat(g.mat, g.n_theta * g.nz)          # flat material id
        self.is_pcm = mat == MAT_PCM
        self.is_cell = mat == MAT_CELL

        cell = self.cfg["cell"]
        rho_cell = cell["mass_kg"] / g.V_cell
        cp_cell = cell["cp_J_kgK"]

        # PCM-side property values (0 when there is no PCM -- the np.where
        # masks below then select the cell value everywhere)
        p_a_s = self.pcm.rho * self.pcm.cp_solid if self.has_pcm else 0.0
        p_a_l = self.pcm.rho * self.pcm.cp_liquid if self.has_pcm else 0.0
        p_cL = self.pcm.rho * self.pcm.latent_heat if self.has_pcm else 0.0
        p_Ts = self.pcm.T_solidus_C if self.has_pcm else -1.0e6
        p_Tl = self.pcm.T_liquidus_C if self.has_pcm else -1.0e6 + 1.0
        p_k = self.pcm.k_solid if self.has_pcm else 0.0
        p_kl = (self.pcm.k_liquid * self.k_enh) if self.has_pcm else 0.0

        # enthalpy parameters (flat, per node)
        self.a_s = np.where(self.is_pcm, p_a_s, rho_cell * cp_cell)
        self.a_l = np.where(self.is_pcm, p_a_l, rho_cell * cp_cell)
        self.cL = np.where(self.is_pcm, p_cL, 0.0)
        self.Ts = np.where(self.is_pcm, p_Ts, -1.0e6)
        self.Tl = np.where(self.is_pcm, p_Tl, -1.0e6 + 1.0)
        self.a_min = np.minimum(self.a_s, self.a_l)
        self.cap_mush = self.a_s + self.cL / (self.Tl - self.Ts)

        # direction-dependent conductivities (solid state; updated with f)
        krs = np.where(self.is_cell, cell["k_radial_W_mK"], p_k)
        kts = np.where(self.is_cell, cell["k_theta_W_mK"], p_k)
        kzs = np.where(self.is_cell, cell["k_axial_W_mK"], p_k)
        krl = np.where(self.is_cell, cell["k_radial_W_mK"], p_kl)
        ktl = np.where(self.is_cell, cell["k_theta_W_mK"], p_kl)
        kzl = np.where(self.is_cell, cell["k_axial_W_mK"], p_kl)
        self.k_solid = {"r": krs, "t": kts, "z": kzs}
        self.k_liq = {"r": krl, "t": ktl, "z": kzl}
        self.k_dir = {d: k_s.copy() for d, k_s in self.k_solid.items()}

        # state
        self.T_ref = self.T_init_C
        self.T = np.full(N, self.T_init_C)
        self.H = self._H_of_T(self.T)
        self.H0 = self.H.copy()
        self.f = np.zeros(N)

        # source bookkeeping
        self.cell_idx = np.flatnonzero(self.is_cell)
        self.pcm_idx = np.flatnonzero(self.is_pcm)
        self.src_frac = g.V_flat[self.cell_idx] / g.V_cell

        # ring index of the outermost cell ring (cell surface temperature)
        surf_ring = g.n_cell_rings - 1
        ring_idx = np.arange(N).reshape(g.shape)[surf_ring, :, :].ravel()
        self.surf_idx = ring_idx
        outer_ring = g.nr - 1
        self.outer_idx = np.arange(N).reshape(g.shape)[outer_ring, :, :].ravel()

    def _select_boundaries(self) -> None:
        g = self.grid
        keep = np.ones(len(g.bnd_idx), dtype=bool)
        if self.insulated_ends:
            keep &= g.bnd_kind == 0
        self.bnd_idx = g.bnd_idx[keep]
        self.bnd_A = g.bnd_A[keep]
        self.bnd_rw = g.bnd_r_wall[keep]
        self.bnd_kind = g.bnd_kind[keep]
        self.bnd_d_half = g.bnd_d_half[keep]
        self.bnd_D_outer = 2.0 * g.r_out

    # ------------------------------------------------------------------ #
    #  enthalpy <-> temperature (exact, vectorised)
    # ------------------------------------------------------------------ #
    def _H_of_T(self, T: np.ndarray) -> np.ndarray:
        f = np.clip((T - self.Ts) / (self.Tl - self.Ts), 0.0, 1.0)
        return (self.a_s * (T - self.T_ref) + self.cL * f
                + (self.a_l - self.a_s) * np.maximum(T - self.Tl, 0.0))

    def _T_of_H(self, H: np.ndarray) -> np.ndarray:
        H1 = self.a_s * (self.Ts - self.T_ref)
        H2 = H1 + self.a_s * (self.Tl - self.Ts) + self.cL
        T = np.where(H <= H1,
                     self.T_ref + H / self.a_s,
                     self.Ts + (H - H1) / self.cap_mush)
        T = np.where(H > H2, self.Tl + (H - H2) / self.a_l, T)
        return T

    # ------------------------------------------------------------------ #
    #  conductances & stability
    # ------------------------------------------------------------------ #
    def _update_k(self) -> None:
        for d in ("r", "t", "z"):
            self.k_dir[d] = (self.k_solid[d]
                             + self.f * (self.k_liq[d] - self.k_solid[d]))

    def _conductances(self) -> tuple[dict, np.ndarray]:
        g = self.grid
        G = {}
        for d, (ia, ib, A, d1, d2, rex) in {
            "r": (g.ia_r, g.ib_r, g.A_r, g.d1_r, g.d2_r, g.rex_r),
            "t": (g.ia_t, g.ib_t, g.A_t, g.d1_t, g.d2_t, g.rex_t),
            "z": (g.ia_z, g.ib_z, g.A_z, g.d1_z, g.d2_z, g.rex_z),
        }.items():
            k = self.k_dir[d]
            G[d] = A / (d1 / k[ia] + d2 / k[ib] + rex)

        # boundary: convection (+ linearized radiation) with optional wall
        T_b = self.T[self.bnd_idx]
        if self.h_mode == "churchill_chu":
            T_surf_K = float(np.mean(T_b)) + 273.15
            h_c = h_churchill_chu(T_surf_K, self.T_amb_K, self.bnd_D_outer)
        else:
            h_c = self.h_const
        Ts_K = T_b + 273.15
        h_rad = self.eps * SIGMA * (Ts_K + self.T_amb_K) * (Ts_K**2 + self.T_amb_K**2)
        h_tot = h_c + h_rad
        # series: half-cell conduction + (convection+radiation) + wall
        # G_face = A / (d_half/k_node + 1/h_tot + R_wall)
        # (radial faces use k_r, end-cap faces use k_z)
        k_bnd = np.where(self.bnd_kind == 0,
                         self.k_dir["r"][self.bnd_idx],
                         self.k_dir["z"][self.bnd_idx])
        d_half_k = self.bnd_d_half / k_bnd
        with np.errstate(divide="ignore", invalid="ignore"):
            r_tot = np.where(h_tot > 1e-12,
                             d_half_k + 1.0 / np.where(h_tot > 1e-12, h_tot, 1.0)
                             + self.bnd_rw,
                             np.inf)
        Gb = np.where(np.isfinite(r_tot), self.bnd_A / r_tot, 0.0)
        return G, Gb

    def _dt_stable(self, G: dict, Gb: np.ndarray) -> float:
        g = self.grid
        N = self.N
        sumG = (np.bincount(g.ia_r, G["r"], N) + np.bincount(g.ib_r, G["r"], N)
                + np.bincount(g.ia_t, G["t"], N) + np.bincount(g.ib_t, G["t"], N)
                + np.bincount(g.ia_z, G["z"], N) + np.bincount(g.ib_z, G["z"], N)
                + np.bincount(self.bnd_idx, Gb, N))
        return float(np.min(self.a_min * g.V_flat / np.maximum(sumG, 1e-300)))

    # ------------------------------------------------------------------ #
    #  main loop
    # ------------------------------------------------------------------ #
    def run(self, verbose: bool = False) -> CaseResult:
        g = self.grid
        t0 = _time.perf_counter()

        rows: list[dict] = []
        snapshots: dict[float, dict] = {}
        peaks = {"T_cell_mean": -1e9, "T_cell_max": -1e9, "melt_fraction": 0.0}

        E_gen = 0.0
        E_amb = 0.0
        t = 0.0
        dt_prev = self.dt_max
        next_sample = self.sample_every
        snap_remaining = sorted(self.snapshot_times)

        def metrics() -> dict:
            Tc = self.T[self.cell_idx]
            Vc = g.V_flat[self.cell_idx]
            T_cell_mean = float(np.average(Tc, weights=Vc))
            T_cell_max = float(np.max(Tc))
            f_mean = (float(np.average(self.f[self.pcm_idx],
                                       weights=g.V_flat[self.pcm_idx]))
                      if len(self.pcm_idx) else 0.0)
            dU = float(np.sum((self.H - self.H0) * g.V_flat))
            E_lat = float(np.sum(self.f * self.cL * g.V_flat))
            closure = ((E_gen + E_amb - dU)
                       / max(abs(E_gen), abs(E_amb), 1e-9))
            return dict(
                time_s=t,
                soc=float(self.battery.soc(t)),
                q_gen_W=float(self._q_now),
                T_cell_mean_C=T_cell_mean,
                T_cell_max_C=T_cell_max,
                T_cell_surface_C=float(np.mean(self.T[self.surf_idx])),
                T_outer_surface_C=float(np.mean(self.T[self.outer_idx])),
                melt_fraction=f_mean,
                E_gen_J=E_gen,
                E_amb_J=E_amb,
                E_latent_J=E_lat,
                closure_rel=closure,
            )

        self._q_now = self.battery.q_gen_W(0.0, self.T_init_C + 273.15)
        rows.append(metrics())                       # t = 0

        n_steps = 0
        while t < self.t_end - 1e-9:
            self._update_k()
            G, Gb = self._conductances()
            dt = min(self.cfl * self._dt_stable(G, Gb),
                     self.dt_max, dt_prev * self.dt_growth,
                     self.t_end - t)
            if snap_remaining:
                dt = min(dt, max(snap_remaining[0] - t, 1e-6))
            if next_sample - t > 1e-9:
                dt = min(dt, next_sample - t)
            dt = max(dt, 1e-7)

            # --- energy update -------------------------------------------
            T = self.T
            dE = np.zeros(self.N)
            for d, (ia, ib) in {"r": (g.ia_r, g.ib_r),
                                "t": (g.ia_t, g.ib_t),
                                "z": (g.ia_z, g.ib_z)}.items():
                q = G[d] * (T[ib] - T[ia]) * dt
                dE += np.bincount(ia, q, self.N) - np.bincount(ib, q, self.N)
            q_b = Gb * (self.T_amb_C - T[self.bnd_idx]) * dt
            dE += np.bincount(self.bnd_idx, q_b, self.N)
            E_amb += float(np.sum(q_b))

            q_gen = self.battery.q_gen_W(t, self._T_cell_mean_K())
            self._q_now = q_gen
            E_gen += q_gen * dt
            dE[self.cell_idx] += q_gen * self.src_frac * dt

            self.H += dE / g.V_flat
            self.T = self._T_of_H(self.H)
            self.f = np.where(self.is_pcm,
                              np.clip((self.T - self.Ts) / (self.Tl - self.Ts),
                                      0.0, 1.0),
                              0.0)

            # --- bookkeeping ----------------------------------------------
            t += dt
            dt_prev = dt
            n_steps += 1

            Tc = self.T[self.cell_idx]
            peaks["T_cell_max"] = max(peaks["T_cell_max"], float(np.max(Tc)))
            peaks["T_cell_mean"] = max(peaks["T_cell_mean"],
                                       float(np.average(Tc, weights=g.V_flat[self.cell_idx])))
            if len(self.pcm_idx):
                peaks["melt_fraction"] = max(
                    peaks["melt_fraction"],
                    float(np.max(self.f[self.pcm_idx])))

            while snap_remaining and t >= snap_remaining[0] - 1e-9:
                ts = snap_remaining.pop(0)
                T3 = self.T.reshape(g.shape)
                f3 = self.f.reshape(g.shape)
                snapshots[ts] = {
                    "T_rz": T3.mean(axis=1).copy(),
                    "f_rz": f3.mean(axis=1).copy(),
                    "r_mm": g.rc * 1e3,
                    "z_mm": (0.5 * (g.z_faces[:-1] + g.z_faces[1:])) * 1e3,
                }
            while t >= next_sample - 1e-9:
                rows.append(metrics())
                next_sample += self.sample_every

        df = pd.DataFrame(rows)
        run_s = _time.perf_counter() - t0
        if verbose:
            print(f"  case '{self.case_id}': {n_steps} steps in {run_s:.1f} s, "
                  f"closure = {df['closure_rel'].iloc[-1]:.2e}")

        dU = float(np.sum((self.H - self.H0) * g.V_flat))
        energy = {
            "E_generated_J": E_gen,
            "E_to_ambient_J": -E_amb,   # E_amb is net energy INTO the domain
            "E_stored_J": dU,
            "E_latent_J": float(np.sum(self.f * self.cL * g.V_flat)),
            "closure_rel": float(df["closure_rel"].iloc[-1]),
            "n_steps": n_steps,
        }
        return CaseResult(
            case_id=self.case_id, label=self.case["label"],
            pcm_props=self.pcm, grid_summary=g.summary(),
            timeseries=df, snapshots=snapshots, peaks=peaks,
            energy=energy, run_seconds=run_s,
        )

    # ------------------------------------------------------------------ #
    def _T_cell_mean_K(self) -> float:
        Tc = self.T[self.cell_idx]
        w = self.grid.V_flat[self.cell_idx]
        return float(np.average(Tc, weights=w)) + 273.15
