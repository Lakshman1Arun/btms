"""Structured 3-D cylindrical (r, theta, z) finite-difference grid.

The domain is a cylinder of radius ``r_out`` and length ``L`` discretised
into ``nr x n_theta x nz`` control volumes.  Radially there are two zones:

    [ 0 .......... r_c ]  ->  cell region   (nr_cell volumes, heat source)
    [ r_c ........ r_out] ->  PCM jacket    (nr_pcm volumes, phase change)

For the bare-cell case the PCM zone is removed and the outer boundary
coincides with the cell surface.

For every interior face the module precomputes

    A_face   conduction cross-section                       [m2]
    d1, d2   distances from the face to the two cell centres [m]
    R_extra  optional specific contact resistance            [m2-K/W]

so the solver can assemble face conductances each step as

    G = A_face / (d1/k1 + d2/k2 + R_extra)                  [W/K]

using the *current* (phase-dependent) nodal conductivities k1, k2.  This
series-resistance form is exact for steady 1-D flux across the face and
implies harmonic-mean interface conductivities -- the correct treatment at
material interfaces (Incropera et al., Fundamentals of Heat and Mass
Transfer).

Geometric details:
* Node volumes are annular sectors: V = (dtheta/2)(r_out^2 - r_in^2) dz,
  which reduces to the correct wedge with apex on the axis for i = 0.
* theta-faces of annular nodes use the chord distance between centroids;
  the i = 0 wedge nodes are connected through their shared radial
  rectangles (area r_1 x dz) using the centroid-to-centroid distance, so
  the grid remains valid for non-axisymmetric extensions.
* All exterior faces (outer cylinder + both end caps) are collected with
  their areas and optional thin-wall conduction resistance for Robin
  (convection + radiation) boundary conditions.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

__all__ = ["Grid", "build_grid"]

MAT_CELL = 0
MAT_PCM = 1


@dataclass
class Grid:
    """Structured cylindrical FDM grid with precomputed face bookkeeping."""

    # mesh
    rf: np.ndarray            # radial face radii, (nr+1,)
    rc: np.ndarray            # radial cell centres, (nr,)
    z_faces: np.ndarray       # (nz+1,)
    dtheta: float
    shape: tuple[int, int, int]
    mat: np.ndarray           # (nr,) material id per radial ring

    # per-node volumes (identical for every theta & z index of a ring)
    V_ring: np.ndarray        # (nr,) volume of ONE theta-cell of the ring [m3]

    # interior faces ----------------------------------------------------- #
    ia_r: np.ndarray; ib_r: np.ndarray
    A_r: np.ndarray;  d1_r: np.ndarray; d2_r: np.ndarray; rex_r: np.ndarray
    ia_t: np.ndarray; ib_t: np.ndarray
    A_t: np.ndarray;  d1_t: np.ndarray; d2_t: np.ndarray; rex_t: np.ndarray
    ia_z: np.ndarray; ib_z: np.ndarray
    A_z: np.ndarray;  d1_z: np.ndarray; d2_z: np.ndarray; rex_z: np.ndarray

    # boundary faces ----------------------------------------------------- #
    bnd_idx: np.ndarray
    bnd_A: np.ndarray
    bnd_r_wall: np.ndarray        # thin-wall conduction resistance [m2-K/W]
    bnd_kind: np.ndarray          # 0 = outer radial face, 1 = end-cap face
    bnd_d_half: np.ndarray        # node-centre-to-face distance [m]

    # derived quantities -------------------------------------------------- #
    def __post_init__(self) -> None:
        self.nr, self.n_theta, self.nz = self.shape
        self.V_flat = np.repeat(self.V_ring, self.n_theta * self.nz)
        cell_v = (self.V_ring[self.mat == MAT_CELL].sum()
                  * self.n_theta * self.nz)
        pcm_v = (self.V_ring[self.mat == MAT_PCM].sum()
                 * self.n_theta * self.nz)
        self.V_cell = float(cell_v)
        self.V_pcm = float(pcm_v)
        self.r_c = float(self.rf[self.n_cell_rings]) if self.has_pcm \
            else float(self.rf[-1])
        self.r_out = float(self.rf[-1])

    has_pcm: bool = False
    n_cell_rings: int = 0

    # ------------------------------------------------------------------ #
    def idx3(self) -> np.ndarray:
        """Flat indices reshaped to (nr, n_theta, nz)."""
        return np.arange(self.nr * self.n_theta * self.nz).reshape(self.shape)

    def summary(self) -> dict:
        return {
            "grid (r x theta x z)": f"{self.nr} x {self.n_theta} x {self.nz}"
                                    f" = {self.nr * self.n_theta * self.nz} nodes",
            "cell radius (mm)": self.r_c * 1e3,
            "outer radius (mm)": self.r_out * 1e3,
            "cell volume (cm3)": self.V_cell * 1e6,
            "PCM volume (cm3)": self.V_pcm * 1e6,
        }


def build_grid(cfg: dict, has_pcm: bool) -> Grid:
    """Construct the grid from the configuration dictionary."""
    num = cfg["numerics"]
    cell = cfg["cell"]
    jack = cfg["pcm_jacket"]

    r_c = cell["diameter_mm"] * 0.5e-3
    L = cell["length_mm"] * 1e-3
    t_pcm = jack["thickness_mm"] * 1e-3
    r_out = r_c + t_pcm if has_pcm else r_c

    nr_cell = int(num["nr_cell"])
    nr_pcm = int(num["nr_pcm"]) if has_pcm else 0
    n_theta = int(num["n_theta"])
    nz = int(num["nz"])

    # --- radial mesh ------------------------------------------------------
    if has_pcm:
        rf_cell = np.linspace(0.0, r_c, nr_cell + 1)
        rf_pcm = np.linspace(r_c, r_out, nr_pcm + 1)[1:]
        rf = np.concatenate([rf_cell, rf_pcm])
    else:
        rf = np.linspace(0.0, r_c, nr_cell + 1)
    nr = len(rf) - 1
    rc = 0.5 * (rf[:-1] + rf[1:])

    mat = np.full(nr, MAT_CELL, dtype=int)
    if has_pcm:
        mat[nr_cell:] = MAT_PCM

    # --- axial mesh (uniform) ---------------------------------------------
    z_faces = np.linspace(0.0, L, nz + 1)
    dz = L / nz
    dtheta = 2.0 * np.pi / n_theta

    # --- per-ring node volume (per theta cell) -----------------------------
    V_ring = 0.5 * dtheta * (rf[1:] ** 2 - rf[:-1] ** 2) * dz

    # --- face bookkeeping ---------------------------------------------------
    R_contact = jack["contact_resistance_m2K_W"] if has_pcm else 0.0
    R_wall = (jack["enclosure_thickness_mm"] * 1e-3 / jack["enclosure_k_W_mK"]
              if has_pcm else 0.0)

    idx = np.arange(nr * n_theta * nz).reshape(nr, n_theta, nz)

    # radial interior faces -------------------------------------------------
    ia_r = idx[:-1, :, :].ravel()
    ib_r = idx[1:, :, :].ravel()
    A_r = np.repeat(rf[1:-1] * dtheta * dz, n_theta * nz)
    d1_r = np.repeat(rf[1:-1] - rc[:-1], n_theta * nz)
    d2_r = np.repeat(rc[1:] - rf[1:-1], n_theta * nz)
    rex_r = np.zeros_like(A_r)
    if has_pcm and R_contact > 0.0:
        sl = slice((nr_cell - 1) * n_theta * nz, nr_cell * n_theta * nz)
        rex_r[sl] = R_contact

    # theta interior faces ----------------------------------------------------
    chord = 2.0 * rc * np.sin(0.5 * dtheta)          # centroid distance
    A_theta_ring = np.where(np.arange(nr) == 0,
                            rf[1] * dz,                       # wedge: radial rectangle
                            (rf[1:] - rf[:-1]) * dz)          # annular: radial width
    dist_ring = np.where(np.arange(nr) == 0,
                         2.0 * (2.0 / 3.0) * rf[1] * np.sin(0.5 * dtheta),
                         chord)

    ia_t = np.concatenate([idx[:, :-1, :].ravel(), idx[:, -1, :].ravel()])
    ib_t = np.concatenate([idx[:, 1:, :].ravel(), idx[:, 0, :].ravel()])
    A_t = np.concatenate([np.repeat(A_theta_ring, (n_theta - 1) * nz),
                          np.repeat(A_theta_ring, nz)])
    half = np.concatenate([np.repeat(0.5 * dist_ring, (n_theta - 1) * nz),
                           np.repeat(0.5 * dist_ring, nz)])
    d1_t = half.copy()
    d2_t = half.copy()

    # axial interior faces -----------------------------------------------------
    A_z_ring = 0.5 * dtheta * (rf[1:] ** 2 - rf[:-1] ** 2)
    ia_z = idx[:, :, :-1].ravel()
    ib_z = idx[:, :, 1:].ravel()
    A_z = np.repeat(A_z_ring, n_theta * (nz - 1))
    d1_z = np.full_like(A_z, 0.5 * dz)
    d2_z = np.full_like(A_z, 0.5 * dz)

    # boundary faces --------------------------------------------------------
    A_outer = rf[-1] * dtheta * dz
    bnd_idx_outer = idx[-1, :, :].ravel()
    bnd_A_outer = np.full(n_theta * nz, A_outer)
    bnd_rw_outer = np.full(n_theta * nz, R_wall)

    bnd_idx_end = np.concatenate([idx[:, :, 0].ravel(), idx[:, :, -1].ravel()])
    bnd_A_end = np.concatenate([np.repeat(A_z_ring, n_theta),
                                np.repeat(A_z_ring, n_theta)])
    bnd_rw_end = np.zeros_like(bnd_A_end)      # end caps = cell terminals

    bnd_idx = np.concatenate([bnd_idx_outer, bnd_idx_end])
    bnd_A = np.concatenate([bnd_A_outer, bnd_A_end])
    bnd_r_wall = np.concatenate([bnd_rw_outer, bnd_rw_end])
    bnd_kind = np.concatenate([np.zeros_like(bnd_idx_outer),
                               np.ones_like(bnd_idx_end)])
    bnd_d_half = np.concatenate([np.full(n_theta * nz, rf[-1] - rc[-1]),
                                 np.full(2 * nr * n_theta, 0.5 * dz)])

    return Grid(
        rf=rf, rc=rc, z_faces=z_faces, dtheta=dtheta,
        shape=(nr, n_theta, nz), mat=mat, V_ring=V_ring,
        ia_r=ia_r, ib_r=ib_r, A_r=A_r, d1_r=d1_r, d2_r=d2_r, rex_r=rex_r,
        ia_t=ia_t, ib_t=ib_t, A_t=A_t, d1_t=d1_t, d2_t=d2_t,
        rex_t=np.zeros_like(A_t),
        ia_z=ia_z, ib_z=ib_z, A_z=A_z, d1_z=d1_z, d2_z=d2_z,
        rex_z=np.zeros_like(A_z),
        bnd_idx=bnd_idx, bnd_A=bnd_A, bnd_r_wall=bnd_r_wall,
        bnd_kind=bnd_kind, bnd_d_half=bnd_d_half,
        has_pcm=has_pcm, n_cell_rings=nr_cell,
    )
