"""Configuration loading, validation and override utilities.

All model inputs live in a single editable JSON file (config.json).  This
module loads it, applies dictionary overrides (used by the pytest suite to
build reduced test cases) and performs physical/numerical sanity checks so
that a typo in the JSON fails fast with a readable message instead of
producing a silently wrong simulation.
"""

from __future__ import annotations

import copy
import json
from pathlib import Path

__all__ = ["load_config", "apply_overrides", "validate_config"]


def load_config(path: str | Path) -> dict:
    """Load a JSON configuration file and validate it."""
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(f"Config file not found: {path}")
    with path.open("r", encoding="utf-8") as fh:
        cfg = json.load(fh)
    validate_config(cfg)
    return cfg


def apply_overrides(cfg: dict, overrides: dict | None) -> dict:
    """Return a deep copy of *cfg* updated with *overrides* (deep merge).

    Used by the test-suite to derive small/fast configurations from the
    standard one without touching the user's file.
    """
    base = copy.deepcopy(cfg)
    if not overrides:
        return base
    _merge(base, overrides)
    return base


def _merge(target: dict, source: dict) -> None:
    for key, value in source.items():
        if isinstance(value, dict) and isinstance(target.get(key), dict):
            _merge(target[key], value)
        else:
            target[key] = copy.deepcopy(value)


def validate_config(cfg: dict) -> None:
    """Fail fast on physically or numerically inconsistent inputs."""
    errors: list[str] = []

    def require(condition: bool, msg: str) -> None:
        if not condition:
            errors.append(msg)

    # --- cell -------------------------------------------------------------
    cell = cfg["cell"]
    require(cell["diameter_mm"] > 0, "cell.diameter_mm must be > 0")
    require(cell["length_mm"] > 0, "cell.length_mm must be > 0")
    require(cell["mass_kg"] > 0, "cell.mass_kg must be > 0")
    require(cell["capacity_Ah"] > 0, "cell.capacity_Ah must be > 0")
    require(cell["cp_J_kgK"] > 0, "cell.cp_J_kgK must be > 0")
    for key in ("k_radial_W_mK", "k_theta_W_mK", "k_axial_W_mK"):
        require(cell[key] > 0, f"cell.{key} must be > 0")

    # --- battery ----------------------------------------------------------
    bat = cfg["battery"]
    require(bat["r0_ref_ohm"] > 0, "battery.r0_ref_ohm must be > 0")
    n = len(bat["soc_points"])
    require(
        len(bat["r_multiplier_points"]) == n
        and len(bat["du_dt_points_V_K"]) == n,
        "battery SOC tables must have equal lengths",
    )
    require(
        all(b >= a for a, b in zip(bat["soc_points"], bat["soc_points"][1:])),
        "battery.soc_points must be ascending (np.interp requirement)",
    )

    # --- PCM / materials --------------------------------------------------
    par = cfg["materials"]["paraffin"]
    require(
        par["T_liquidus_C"] > par["T_solidus_C"],
        "paraffin T_liquidus_C must exceed T_solidus_C (mushy range)",
    )
    require(par["latent_heat_J_kg"] >= 0, "latent_heat_J_kg must be >= 0")
    require(par["rho_eff_kg_m3"] > 0 and par["cp_solid_J_kgK"] > 0,
            "paraffin rho_eff / cp_solid must be > 0")
    require(par["k_solid_W_mK"] > 0, "paraffin k_solid must be > 0")

    eg = cfg["materials"]["expanded_graphite"]
    require(len(eg["k_wt_pct_anchors"]) == len(eg["k_composite_anchors_W_mK"]),
            "EG conductivity anchors must have equal lengths")
    require(
        all(b > a for a, b in zip(eg["k_wt_pct_anchors"], eg["k_wt_pct_anchors"][1:])),
        "EG wt% anchors must be strictly ascending",
    )
    require(
        all(k2 >= k1 for k1, k2 in
            zip(eg["k_composite_anchors_W_mK"], eg["k_composite_anchors_W_mK"][1:])),
        "EG composite k anchors should be non-decreasing with loading",
    )

    hbn = cfg["materials"]["hbn"]
    require(hbn["aspect_ratio"] > 0, "hbn aspect_ratio must be > 0")
    require(0 < hbn["nielsen_phi_max"] <= 1.0, "hbn nielsen_phi_max in (0, 1]")

    # --- operating --------------------------------------------------------
    op = cfg["operating"]
    require(op["c_rate"] > 0, "operating.c_rate must be > 0")
    require(op["h_mode"] in ("churchill_chu", "constant"),
            "operating.h_mode must be 'churchill_chu' or 'constant'")
    require(0.0 <= op["emissivity"] <= 1.0, "operating.emissivity in [0, 1]")
    require(op["k_liquid_enhancement"] >= 1.0,
            "operating.k_liquid_enhancement must be >= 1.0")

    # --- numerics ---------------------------------------------------------
    num = cfg["numerics"]
    require(num["nr_cell"] >= 3, "numerics.nr_cell must be >= 3")
    require(num["n_theta"] >= 4, "numerics.n_theta must be >= 4")
    require(num["nz"] >= 3, "numerics.nz must be >= 3")
    require(0 < num["cfl"] <= 1.0, "numerics.cfl must be in (0, 1]")
    require(num["dt_min_s"] > 0 and num["dt_max_s"] >= num["dt_min_s"],
            "numerics.dt_min_s > 0 and dt_max_s >= dt_min_s required")

    # --- runtime ----------------------------------------------------------
    rt = cfg["runtime"]
    require(rt["discharge_s"] > 0, "runtime.discharge_s must be > 0")
    require(rt["rest_s"] >= 0, "runtime.rest_s must be >= 0")
    require(rt["sample_every_s"] > 0, "runtime.sample_every_s must be > 0")

    # --- jacket -----------------------------------------------------------
    jack = cfg["pcm_jacket"]
    require(jack["thickness_mm"] > 0, "pcm_jacket.thickness_mm must be > 0")
    require(jack["contact_resistance_m2K_W"] >= 0, "contact resistance >= 0")

    # --- cases ------------------------------------------------------------
    ids = [c["id"] for c in cfg["cases"]]
    require(len(ids) == len(set(ids)), "case ids must be unique")
    valid_types = ("none", "pure", "pw_eg", "pw_hybrid")
    for c in cfg["cases"]:
        require(c["pcm_type"] in valid_types,
                f"case '{c['id']}': pcm_type must be one of {valid_types}")

    if errors:
        raise ValueError("Invalid configuration:\n  - " + "\n  - ".join(errors))
