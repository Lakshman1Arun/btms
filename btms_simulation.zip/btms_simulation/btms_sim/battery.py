"""Battery heat-generation model.

Transient heat generation during a constant-current (CC) discharge with
coulomb-counting SOC, an SOC-dependent ohmic internal resistance and an
SOC-dependent reversible (entropic) term:

    Q(t) = I^2 R(SOC)  -  I * T_cell * (dU/dT)(SOC)          [discharging]
    Q(t) = 0                                                  [rest]

Sign convention: the reversible term follows
    Q_rev = - I T (dU/dT)
so phases of the OCV curve with negative entropic coefficient *add* heat
during discharge and vice versa.  Both R(SOC) and dU/dT(SOC) are supplied as
editable lookup tables in ``config.json`` (default tables are representative
of an NMC 18650 such as the Samsung INR18650-25R).

A constant-heat override (``operating.q_constant_W``) is provided for
verification studies (analytical steady-state test) and for users who prefer
the common "constant q-vol" simplification.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

__all__ = ["BatteryModel"]


@dataclass
class BatteryModel:
    """CC-discharge heat source with SOC-dependent parameters."""

    capacity_Ah: float
    c_rate: float
    r0_ref_ohm: float
    soc_points: list[float]
    r_mult_points: list[float]
    du_dt_points: list[float]          # V/K
    discharge_s: float
    q_constant_W: float | None = None  # optional override

    def __post_init__(self) -> None:
        self.I_A = self.c_rate * self.capacity_Ah          # discharge current
        # Full discharge time from coulomb counting at the rated capacity
        self.t_full_discharge_s = 3600.0 / self.c_rate

    # ------------------------------------------------------------------ #
    def soc(self, t: float | np.ndarray) -> float | np.ndarray:
        """State of charge by coulomb counting (1 = full, 0 = empty)."""
        s = 1.0 - np.asarray(t, dtype=float) / self.t_full_discharge_s
        return np.clip(s, 0.0, 1.0) if s.ndim else float(np.clip(s, 0.0, 1.0))

    def R_internal(self, soc):
        """Ohmic internal resistance [ohm] at the given SOC (scalar or array)."""
        return np.interp(soc, self.soc_points, self.r_mult_points) * self.r0_ref_ohm

    def du_dt(self, soc):
        """Entropic heat coefficient dU/dT [V/K] (scalar or array)."""
        return np.interp(soc, self.soc_points, self.du_dt_points)

    # ------------------------------------------------------------------ #
    def q_gen_W(self, t: float, T_cell_K: float) -> float:
        """Total instantaneous heat generation rate [W]."""
        if t >= self.discharge_s:                 # rest period
            return 0.0
        if self.q_constant_W is not None:         # verification override
            return float(self.q_constant_W)

        soc = float(np.clip(1.0 - t / self.t_full_discharge_s, 0.0, 1.0))
        q_joule = self.I_A**2 * self.R_internal(soc)
        q_rev = -self.I_A * T_cell_K * self.du_dt(soc)
        return float(q_joule + q_rev)

    # ------------------------------------------------------------------ #
    def energy_expected_J(self) -> float:
        """Integral of the Joule term over the full discharge (analytic
        reference for the battery energy test; the entropic term integrates
        to approximately zero over a full curve and is excluded here)."""
        socs = np.linspace(1.0, 0.0, 2001)
        t_of_soc = (1.0 - socs) * self.t_full_discharge_s
        q = self.I_A**2 * self.R_internal(socs)
        return float(np.trapezoid(q, t_of_soc))
