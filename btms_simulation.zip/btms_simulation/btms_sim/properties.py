"""Material properties and effective-property mixing models.

This module turns the *standard* base-material data in ``config.json``
(paraffin wax, expanded graphite, ZnO, h-BN) into the effective properties
of each composite PCM using classical engineering mixing models:

* **Maxwell-Eucken** (Maxwell 1873) -- dilute spherical inclusions; used for
  the near-spherical ZnO nanoparticles.
* **Lewis-Nielsen** (Lewis & Nielsen 1970) -- modified Halpin-Tsai form that
  accounts for particle shape/agglomeration via the geometry parameter ``A``
  and maximum packing fraction ``phi_m``; used for high-aspect-ratio h-BN
  platelets.
* **Calibrated interpolation** for expanded graphite -- isotropic effective
  medium theories badly underestimate the conductivity of percolating
  graphite networks, so the composite conductivity is interpolated from
  published PW/EG measurements (Mills & Al-Hallaj 2005; Sari 2004; Zhong et
  al. 2010).  The anchor points are editable in ``config.json``.

Density, specific heat and latent heat follow simple mass-fraction rule of
mixtures (with density computed on an inverse-volume basis), which is the
standard treatment in composite-PCM literature.

Every value can be overridden by editing ``config.json`` -- no code changes
are required.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

__all__ = [
    "PCMProperties",
    "maxwell_eucken",
    "lewis_nielsen",
    "mass_to_volume_fractions",
    "build_pcm_properties",
]


# --------------------------------------------------------------------------- #
#  Mixing models
# --------------------------------------------------------------------------- #
def maxwell_eucken(k_m: float, k_p: float, phi: float) -> float:
    """Maxwell-Eucken effective thermal conductivity (spherical inclusions).

    k_eff = k_m * [k_p + 2 k_m + 2 phi (k_p - k_m)] /
                    [k_p + 2 k_m -   phi (k_p - k_m)]

    Valid for dilute, non-interacting, approximately spherical particles;
    reduces to k_m at phi = 0 and to k_p at phi = 1, and respects the
    Hashin-Shtrikman bounds on the whole range.
    """
    if phi <= 0.0:
        return float(k_m)
    num = k_p + 2.0 * k_m + 2.0 * phi * (k_p - k_m)
    den = k_p + 2.0 * k_m - phi * (k_p - k_m)
    return float(k_m * num / den)


def lewis_nielsen(k_m: float, k_p: float, phi: float,
                  A: float, phi_max: float) -> float:
    """Lewis-Nielsen model for non-spherical inclusions.

    k_c/k_m = (1 + A B phi) / (1 - B psi phi)
    B   = (k_p/k_m - 1) / (k_p/k_m + A)
    psi = 1 + (1 - phi_max)/phi_max^2 * phi

    ``A`` encodes particle geometry and orientation relative to the heat-flux
    direction (A = 2 spheres, A ~ 5-10 for 3-D randomly oriented platelets,
    A ~ 27.5 for platelets perpendicular to the flux).  ``phi_max`` is the
    maximum packing fraction (~0.64 random loose pack).
    """
    if phi <= 0.0:
        return float(k_m)
    if phi >= phi_max:
        raise ValueError(f"Volume fraction {phi:.3f} exceeds phi_max {phi_max}")
    r = k_p / k_m
    B = (r - 1.0) / (r + A)
    psi = 1.0 + (1.0 - phi_max) / phi_max**2 * phi
    return float(k_m * (1.0 + A * B * phi) / (1.0 - B * psi * phi))


def mass_to_volume_fractions(w: dict[str, float], rho: dict[str, float]) -> dict[str, float]:
    """Convert mass fractions to volume fractions from constituent densities."""
    v = {name: w[name] / rho[name] for name in w}
    total = sum(v.values())
    return {name: v[name] / total for name in v}


# --------------------------------------------------------------------------- #
#  Composite data container
# --------------------------------------------------------------------------- #
@dataclass
class PCMProperties:
    """Effective thermo-physical properties of a (possibly composite) PCM."""

    key: str                       # 'pure' | 'pw_eg' | 'pw_hybrid'
    name: str
    T_solidus_C: float
    T_liquidus_C: float
    rho: float                     # kg/m3 (effective)
    cp_solid: float                # J/kg-K
    cp_liquid: float               # J/kg-K
    k_solid: float                 # W/m-K (effective)
    k_liquid: float                # W/m-K (effective, before melt-convection enhancement)
    latent_heat: float             # J/kg
    composition: dict = field(default_factory=dict)   # for reporting
    notes: str = ""

    @property
    def rho_cp_solid(self) -> float:
        return self.rho * self.cp_solid

    @property
    def volumetric_latent_heat(self) -> float:
        return self.rho * self.latent_heat      # J/m3


# --------------------------------------------------------------------------- #
#  Composite builders
# --------------------------------------------------------------------------- #
def _rule_of_mixtures(pw: dict, fillers: list[tuple[str, dict, float]],
                      T_field: str) -> tuple[float, float, float, float]:
    """Mass-fraction rule of mixtures for rho (inverse), cp, latent heat.

    Returns (rho, cp_solid, cp_liquid, latent_heat).
    """
    w_pw = 1.0 - sum(w for _, _, w in fillers)
    inv_rho = w_pw / pw["rho_eff_kg_m3"]
    cp_s = w_pw * pw["cp_solid_J_kgK"]
    cp_l = w_pw * pw["cp_liquid_J_kgK"]
    for _, props, w in fillers:
        inv_rho += w / props["rho_kg_m3"]
        cp_s += w * props["cp_J_kgK"]
        cp_l += w * props["cp_J_kgK"]
    rho = 1.0 / inv_rho
    latent = w_pw * pw["latent_heat_J_kg"]       # only the wax carries latent heat
    return rho, cp_s, cp_l, latent


def build_pcm_properties(cfg: dict, pcm_type: str) -> PCMProperties | None:
    """Build effective PCM properties for the requested case type.

    Parameters
    ----------
    cfg       : full simulation configuration dict
    pcm_type  : 'none' | 'pure' | 'pw_eg' | 'pw_hybrid'
    """
    if pcm_type == "none":
        return None

    pw = cfg["materials"]["paraffin"]

    if pcm_type == "pure":
        return PCMProperties(
            key="pure",
            name=pw["name"],
            T_solidus_C=pw["T_solidus_C"],
            T_liquidus_C=pw["T_liquidus_C"],
            rho=pw["rho_eff_kg_m3"],
            cp_solid=pw["cp_solid_J_kgK"],
            cp_liquid=pw["cp_liquid_J_kgK"],
            k_solid=pw["k_solid_W_mK"],
            k_liquid=pw["k_liquid_W_mK"],
            latent_heat=pw["latent_heat_J_kg"],
            composition={"paraffin": 1.0},
            notes="Base paraffin wax, literature data used as-is.",
        )

    if pcm_type == "pw_eg":
        w_eg = cfg["composites"]["pw_eg"]["eg_wt_pct"] / 100.0
        if not 0.0 < w_eg < 1.0:
            raise ValueError("eg_wt_pct must be in (0, 100)")
        eg = cfg["materials"]["expanded_graphite"]
        fillers = [("expanded_graphite", eg, w_eg)]
        rho, cp_s, cp_l, latent = _rule_of_mixtures(pw, fillers, "cp")

        # Conductivity: calibrated interpolation of measured PW/EG data.
        k_solid = float(np.interp(w_eg * 100.0,
                                  eg["k_wt_pct_anchors"],
                                  eg["k_composite_anchors_W_mK"]))
        # Liquid phase keeps the same solid/liquid ratio as the base wax
        # (the graphite skeleton still dominates heat spreading).
        k_liquid = k_solid * (pw["k_liquid_W_mK"] / pw["k_solid_W_mK"])
        return PCMProperties(
            key="pw_eg",
            name=f"Paraffin + {w_eg*100:.4g} wt% EG composite",
            T_solidus_C=pw["T_solidus_C"],
            T_liquidus_C=pw["T_liquidus_C"],
            rho=rho, cp_solid=cp_s, cp_liquid=cp_l,
            k_solid=k_solid, k_liquid=k_liquid, latent_heat=latent,
            composition={"paraffin": 1.0 - w_eg, "expanded_graphite": w_eg},
            notes=("k_solid interpolated from published PW/EG measurements "
                   "(Mills & Al-Hallaj 2005; Sari 2004; Zhong et al. 2010); "
                   "rho/cp/L by mass-fraction rule of mixtures."),
        )

    if pcm_type == "pw_hybrid":
        cz = cfg["composites"]["pw_hybrid"]["zno_wt_pct"] / 100.0
        cb = cfg["composites"]["pw_hybrid"]["hbn_wt_pct"] / 100.0
        zno, hbn = cfg["materials"]["zno"], cfg["materials"]["hbn"]
        if cz + cb >= 1.0:
            raise ValueError("Total nanoparticle loading must be < 100 wt%")
        fillers = [("zno", zno, cz), ("hbn", hbn, cb)]
        rho, cp_s, cp_l, latent = _rule_of_mixtures(pw, fillers, "cp")

        # Volume fractions of everything
        w_map = {"paraffin": 1.0 - cz - cb, "zno": cz, "hbn": cb}
        rho_map = {"paraffin": pw["rho_eff_kg_m3"],
                   "zno": zno["rho_kg_m3"], "hbn": hbn["rho_kg_m3"]}
        phi = mass_to_volume_fractions(w_map, rho_map)

        # Sequential EMT: ZnO (near-spherical) via Maxwell-Eucken, then h-BN
        # platelets via Lewis-Nielsen on the resulting effective medium.
        k_step1 = maxwell_eucken(pw["k_solid_W_mK"], zno["k_W_mK"], phi["zno"])
        k_solid = lewis_nielsen(k_step1, hbn["k_W_mK"], phi["hbn"],
                                hbn["nielsen_A"], hbn["nielsen_phi_max"])
        k_liquid = k_solid * (pw["k_liquid_W_mK"] / pw["k_solid_W_mK"])
        return PCMProperties(
            key="pw_hybrid",
            name=(f"Paraffin + {cz*100:.4g} wt% ZnO + {cb*100:.4g} wt% h-BN "
                  "hybrid nanocomposite"),
            T_solidus_C=pw["T_solidus_C"],
            T_liquidus_C=pw["T_liquidus_C"],
            rho=rho, cp_solid=cp_s, cp_liquid=cp_l,
            k_solid=k_solid, k_liquid=k_liquid, latent_heat=latent,
            composition=w_map,
            notes=("ZnO via Maxwell-Eucken, then h-BN platelets via "
                   "Lewis-Nielsen (sequential effective-medium approach); "
                   "rho/cp/L by mass-fraction rule of mixtures."),
        )

    raise ValueError(f"Unknown pcm_type '{pcm_type}'")
