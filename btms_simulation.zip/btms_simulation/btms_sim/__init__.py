"""btms_sim -- 3-D transient thermal simulation of a cylindrical Li-ion cell
with passive phase-change-material (PCM) thermal management.

Case study: Samsung INR18650-25R (2.5 Ah) at 2C discharge, 40 degC ambient,
comparing four configurations:
  1. bare cell (natural convection only, no fins),
  2. base paraffin wax (PW) jacket,
  3. PW + 5 wt% expanded graphite (EG) composite jacket,
  4. PW + ZnO + h-BN hybrid nanocomposite jacket.

Numerical core: explicit finite-difference enthalpy method on a structured
cylindrical (r, theta, z) grid with adaptive time stepping.
"""

__version__ = "1.0.0"
