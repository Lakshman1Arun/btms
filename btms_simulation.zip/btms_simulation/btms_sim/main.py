"""Simulation orchestrator: runs all configured cases and produces outputs."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from . import __version__
from .config import load_config
from .postprocess import (compute_metrics_table, export_csvs, make_plots,
                          write_report)
from .solver import ThermalSolver

__all__ = ["main"]


def _pcm_grid_summary(results: dict) -> dict:
    """Grid summary of the first PCM case (the full mesh); falls back to the
    first case for bare-only studies."""
    for res in results.values():
        if res.has_pcm:
            return res.grid_summary
    return results[list(results)[0]].grid_summary


def run_study(cfg: dict, outdir: str | Path = "results",
              case_filter: list[str] | None = None,
              verbose: bool = True) -> dict:
    """Run every case in the configuration and write all outputs.

    Returns a dict with the CaseResult objects keyed by case id.
    """
    outdir = Path(outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    cases = cfg["cases"]
    if case_filter:
        cases = [c for c in cases if c["id"] in case_filter]
        if not cases:
            raise ValueError(f"No case matched filter {case_filter}")

    if verbose:
        print("=" * 72)
        print("BTMS PCM comparison simulation")
        print(f"  config  : {cfg['meta']['title']}")
        print(f"  version : {__version__}")
        print(f"  cases   : {[c['id'] for c in cases]}")
        print(f"  outputs : {outdir.resolve()}")
        print("=" * 72)

    results = {}
    for case in cases:
        solver = ThermalSolver(cfg, case)
        if verbose:
            print(f"\n--- case '{case['id']}' ({case['label']}) ---")
            for k, v in solver.grid.summary().items():
                print(f"    {k}: {v}")
        res = solver.run(verbose=verbose)
        results[case["id"]] = res

    # ---------------- post-processing ----------------
    op = cfg["operating"]
    rt = cfg["runtime"]
    metrics = compute_metrics_table(results,
                                    t_max_C=cfg["limits"]["t_max_C"],
                                    t_eod_s=rt["discharge_s"])
    csvs = export_csvs(results, outdir)
    figs = make_plots(results, metrics,
                      t_max_C=cfg["limits"]["t_max_C"],
                      t_eod_s=rt["discharge_s"],
                      t_amb_C=op["ambient_C"],
                      outdir=outdir)

    pcm_rows = []
    for cid, res in results.items():
        if res.pcm_props is not None:
            p = res.pcm_props
            pcm_rows.append({"case": cid, "name": p.name,
                             "k_solid": p.k_solid, "latent": p.latent_heat})
    report = write_report(results, metrics,
                          t_max_C=cfg["limits"]["t_max_C"],
                          t_eod_s=rt["discharge_s"],
                          t_amb_C=op["ambient_C"],
                          c_rate=op["c_rate"],
                          cell_model=cfg["cell"]["model"],
                          pcm_summary_rows=pcm_rows,
                          grid_summary=_pcm_grid_summary(results),
                          outdir=outdir)

    if verbose:
        print("\n" + "=" * 72)
        print("Key metrics")
        print("-" * 72)
        with __import__("pandas").option_context("display.width", 160,
                                                 "display.max_columns", 20):
            print(metrics.round(3).to_string())
        print("-" * 72)
        print("Outputs written:")
        for p in csvs + figs + [report]:
            print(f"  {p}")
        print("=" * 72)

    return results


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="python -m btms_sim",
        description=("3-D transient thermal simulation of a 18650 Li-ion cell "
                     "with PCM-based passive thermal management."))
    parser.add_argument("-c", "--config", default="config.json",
                        help="path to the JSON configuration file "
                             "(default: config.json)")
    parser.add_argument("-o", "--outdir", default="results",
                        help="output directory (default: results)")
    parser.add_argument("--cases", nargs="+", default=None,
                        help="run only these case ids (default: all)")
    parser.add_argument("--version", action="version",
                        version=f"btms_sim {__version__}")
    args = parser.parse_args(argv)

    cfg = load_config(args.config)
    run_study(cfg, outdir=args.outdir, case_filter=args.cases)
    return 0


if __name__ == "__main__":
    sys.exit(main())
