"""Post-processing: engineering metrics, plots, CSV export, markdown report.

Produces (per simulation run, in the chosen output directory):

* ``timeseries_<case>.csv``          -- per-case transient data
* ``fig1_cell_temperature.png``      -- mean/max cell temperature histories
* ``fig2_melt_fraction.png``         -- PCM melt-fraction histories
* ``fig3_metrics.png``               -- 2x2 key-metric comparison bars
* ``fig4_radial_profiles.png``       -- mid-plane radial temperature profiles
* ``fig5_rz_contours.png``           -- (r, z) temperature contours at EOD
* ``report.md``                      -- auto-generated results report

All figures use ``constrained_layout`` and a consistent per-case colour
scheme; labels are in English (matching the project language).
"""

from __future__ import annotations

from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from .solver import CaseResult

__all__ = ["compute_metrics_table", "export_csvs", "make_plots", "write_report"]

CASE_COLORS = {
    "bare": "#555555",
    "pw": "#1f77b4",
    "pw_eg5": "#d62728",
    "pw_hybrid": "#2ca02c",
}
CASE_STYLES = {
    "bare": "--", "pw": "-", "pw_eg5": "-", "pw_hybrid": "-",
}

plt.rcParams.update({
    "figure.dpi": 110, "savefig.dpi": 150, "font.size": 10,
    "axes.grid": True, "grid.alpha": 0.3, "axes.axisbelow": True,
    "lines.linewidth": 1.7, "axes.titlesize": 10.5,
})


# --------------------------------------------------------------------------- #
#  Metrics
# --------------------------------------------------------------------------- #
def compute_metrics_table(results: dict[str, CaseResult], t_max_C: float,
                          t_eod_s: float) -> pd.DataFrame:
    """Aggregate the engineering comparison metrics for all cases."""
    rows = []
    for cid, res in results.items():
        df = res.timeseries
        above_mean = df["T_cell_mean_C"] > t_max_C
        above_max = df["T_cell_max_C"] > t_max_C
        # uniform sampling -> simple counts are exact
        dt = float(np.median(np.diff(df["time_s"])))
        eod = df[df["time_s"] <= t_eod_s + 1e-9]
        max_radial_dt = float(np.max(eod["T_cell_mean_C"] - eod["T_cell_surface_C"]))

        row = {
            "case": cid,
            "label": res.label,
            "peak T_cell mean (C)": res.peaks["T_cell_mean"],
            "peak T_cell max (C)": res.peaks["T_cell_max"],
            f"time above {t_max_C:.0f} C, mean (min)": above_mean.sum() * dt / 60.0,
            f"time above {t_max_C:.0f} C, max (min)": above_max.sum() * dt / 60.0,
            "T rise at EOD (C)": float(eod["T_cell_mean_C"].iloc[-1] - df["T_cell_mean_C"].iloc[0]),
            "max radial dT in cell (C)": max_radial_dt,
        }
        if res.has_pcm:
            row["melt fraction @ EOD (-)"] = float(eod["melt_fraction"].iloc[-1])
            row["max local melt fraction (-)"] = res.peaks["melt_fraction"]
            row["latent energy used (kJ)"] = res.energy["E_latent_J"] / 1e3
        else:
            row["melt fraction @ EOD (-)"] = np.nan
            row["max local melt fraction (-)"] = np.nan
            row["latent energy used (kJ)"] = np.nan
        row["energy to ambient (kJ)"] = res.energy["E_to_ambient_J"] / 1e3
        row["energy closure (ppm)"] = abs(res.energy["closure_rel"]) * 1e6
        rows.append(row)
    return pd.DataFrame(rows).set_index("case")


def _df_to_markdown(df: pd.DataFrame, floatfmt: str = ".3f") -> str:
    """Minimal dependency-free DataFrame -> markdown table formatter."""
    cols = [str(c) for c in df.columns]
    lines = ["| case | " + " | ".join(cols) + " |",
             "|" + "------|" * (len(cols) + 1)]
    for idx, row in df.iterrows():
        cells = []
        for v in row:
            if isinstance(v, float):
                cells.append("--" if not np.isfinite(v) else format(v, floatfmt))
            else:
                cells.append(str(v))
        lines.append(f"| {idx} | " + " | ".join(cells) + " |")
    return "\n".join(lines)


# --------------------------------------------------------------------------- #
#  CSV export
# --------------------------------------------------------------------------- #
def export_csvs(results: dict[str, CaseResult], outdir: Path) -> list[Path]:
    outdir.mkdir(parents=True, exist_ok=True)
    paths = []
    for cid, res in results.items():
        p = outdir / f"timeseries_{cid}.csv"
        res.timeseries.to_csv(p, index=False, float_format="%.6g")
        paths.append(p)
    return paths


# --------------------------------------------------------------------------- #
#  Plots
# --------------------------------------------------------------------------- #
def _color(cid: str) -> str:
    return CASE_COLORS.get(cid, None)


def make_plots(results: dict[str, CaseResult], metrics: pd.DataFrame,
               t_max_C: float, t_eod_s: float, t_amb_C: float,
               outdir: Path) -> list[Path]:
    outdir.mkdir(parents=True, exist_ok=True)
    paths = []
    t_max_C_lim = t_max_C

    # ---- fig 1: cell temperature histories --------------------------------
    fig, axes = plt.subplots(1, 2, figsize=(10.5, 4.2), constrained_layout=True)
    for ax, col, ttl in zip(axes,
                            ["T_cell_mean_C", "T_cell_max_C"],
                            ["Cell mean temperature",
                             "Cell maximum temperature"]):
        for cid, res in results.items():
            df = res.timeseries
            ax.plot(df["time_s"] / 60.0, df[col],
                    CASE_STYLES.get(cid, "-"), color=_color(cid), label=res.label)
        ax.axhline(t_max_C_lim, color="k", ls=":", lw=1.0)
        ax.axhline(t_amb_C, color="tab:cyan", ls=":", lw=1.0)
        ax.axvline(t_eod_s / 60.0, color="k", ls="--", lw=0.8, alpha=0.5)
        ax.set_xlabel("time (min)")
        ax.set_ylabel("temperature (degC)")
        ax.set_title(ttl)
    axes[0].legend(fontsize=8, loc="upper left")
    axes[1].text(0.99, t_max_C_lim + 0.3, f"{t_max_C_lim:.0f} degC limit",
                 ha="right", fontsize=8, transform=axes[1].get_yaxis_transform())
    fig.savefig(outdir / "fig1_cell_temperature.png")
    plt.close(fig)
    paths.append(outdir / "fig1_cell_temperature.png")

    # ---- fig 2: melt fraction ----------------------------------------------
    fig, ax = plt.subplots(figsize=(7.0, 4.2), constrained_layout=True)
    for cid, res in results.items():
        if not res.has_pcm:
            continue
        df = res.timeseries
        ax.plot(df["time_s"] / 60.0, df["melt_fraction"] * 100.0,
                color=_color(cid), label=res.label)
        feod = df[df["time_s"] <= t_eod_s + 1e-9]["melt_fraction"].iloc[-1]
        ax.annotate(f"{feod*100:.1f}% @ EOD",
                    xy=(t_eod_s / 60.0, feod * 100.0),
                    xytext=(8, 6), textcoords="offset points", fontsize=8,
                    color=_color(cid))
    ax.axvline(t_eod_s / 60.0, color="k", ls="--", lw=0.8, alpha=0.5)
    ax.set_xlabel("time (min)")
    ax.set_ylabel("melt fraction (%)")
    ax.set_title("PCM melt fraction (volume-averaged)")
    ax.legend(fontsize=8)
    fig.savefig(outdir / "fig2_melt_fraction.png")
    plt.close(fig)
    paths.append(outdir / "fig2_melt_fraction.png")

    # ---- fig 3: key metrics bars -------------------------------------------
    fig, axes = plt.subplots(2, 2, figsize=(10.0, 7.0), constrained_layout=True)
    cids = list(results.keys())
    colors = [_color(c) for c in cids]

    panels = [
        ("peak T_cell max (C)", "Peak cell max temperature (degC)", axes[0, 0]),
        (f"time above {t_max_C_lim:.0f} C, max (min)",
         f"Time above {t_max_C_lim:.0f} degC, cell max (min)", axes[0, 1]),
        ("energy to ambient (kJ)", "Energy rejected to ambient (kJ)", axes[1, 0]),
        ("max local melt fraction (-)", "Max local melt fraction (-)", axes[1, 1]),
    ]
    for col, ttl, ax in panels:
        vals = [metrics.loc[c, col] if c in metrics.index else np.nan for c in cids]
        ax.bar(range(len(cids)), vals, color=colors)
        ax.set_xticks(range(len(cids)))
        ax.set_xticklabels(cids, fontsize=8, rotation=12)
        ax.set_title(ttl)
        for i, v in enumerate(vals):
            if np.isfinite(v):
                ax.text(i, v, f"{v:.3g}" if abs(v) < 1000 else f"{v:.2e}",
                        ha="center", va="bottom", fontsize=8)
    fig.suptitle("Configuration comparison -- key thermal metrics", fontsize=11)
    fig.savefig(outdir / "fig3_metrics.png")
    plt.close(fig)
    paths.append(outdir / "fig3_metrics.png")

    # ---- fig 4: radial profiles at mid-height ------------------------------
    snap_times = sorted({t for res in results.values() for t in res.snapshots})
    if snap_times:
        fig, axes = plt.subplots(2, 2, figsize=(10.0, 7.2),
                                 constrained_layout=True, sharey=False)
        for ax, cid in zip(axes.ravel(), results.keys()):
            res = results[cid]
            for ts in snap_times:
                if ts not in res.snapshots:
                    continue
                snap = res.snapshots[ts]
                mid = len(snap["z_mm"]) // 2
                ax.plot(snap["r_mm"], snap["T_rz"][:, mid],
                        label=f"t = {ts/60:.0f} min")
            ax.set_title(f"{cid}: {res.label}", fontsize=9)
            ax.set_xlabel("radius (mm)")
            ax.set_ylabel("T (degC)")
            ax.legend(fontsize=7)
        fig.suptitle("Mid-plane radial temperature profiles (theta-averaged)",
                     fontsize=11)
        fig.savefig(outdir / "fig4_radial_profiles.png")
        plt.close(fig)
        paths.append(outdir / "fig4_radial_profiles.png")

    # ---- fig 5: (r, z) contours near end of discharge -----------------------
    if snap_times:
        tt = min(snap_times, key=lambda s: abs(s - t_eod_s))
        fields = [(cid, results[cid].snapshots[tt])
                  for cid in results if tt in results[cid].snapshots]
        if fields:
            n = len(fields)
            fig, axes = plt.subplots(1, n, figsize=(3.1 * n, 3.6),
                                     constrained_layout=True)
            if n == 1:
                axes = [axes]
            vmin = min(f["T_rz"].min() for _, f in fields)
            vmax = max(f["T_rz"].max() for _, f in fields)
            for ax, (cid, f) in zip(axes, fields):
                im = ax.pcolormesh(f["r_mm"], f["z_mm"], f["T_rz"].T,
                                   cmap="inferno", shading="auto",
                                   vmin=vmin, vmax=vmax)
                ax.set_title(f"{cid}", fontsize=9)
                ax.set_xlabel("r (mm)")
                ax.set_ylabel("z (mm)")
            cb = fig.colorbar(im, ax=axes, shrink=0.9)
            cb.set_label(f"T (degC), t = {tt/60:.0f} min")
            fig.savefig(outdir / "fig5_rz_contours.png")
            plt.close(fig)
            paths.append(outdir / "fig5_rz_contours.png")

    return paths


# --------------------------------------------------------------------------- #
#  Report
# --------------------------------------------------------------------------- #
def write_report(results: dict[str, CaseResult], metrics: pd.DataFrame,
                 t_max_C: float, t_eod_s: float, t_amb_C: float,
                 c_rate: float, cell_model: str,
                 pcm_summary_rows: list[dict],
                 grid_summary: dict, outdir: Path) -> Path:
    outdir.mkdir(parents=True, exist_ok=True)
    L = []
    ap = L.append

    ap("# Battery Thermal Management Simulation -- Results Report")
    ap("")
    ap(f"**Cell:** {cell_model}  ")
    ap(f"**Load:** constant-current {c_rate:.0f}C discharge to SOC = 0, "
       f"then 10 min rest  ")
    ap(f"**Ambient / initial temperature:** {t_amb_C:.1f} degC  ")
    ap(f"**Temperature limit used for metrics:** {t_max_C:.1f} degC  ")
    ap(f"**Grid:** {grid_summary['grid (r x theta x z)']} "
       "(PCM-case mesh; the bare case omits the PCM radial rings)")
    ap("")

    ap("## 1. Configurations compared")
    ap("")
    ap("| case | description |")
    ap("|------|-------------|")
    for cid, res in results.items():
        ap(f"| `{cid}` | {res.label} |")
    ap("")

    ap("## 2. Effective PCM properties (computed by the mixing models)")
    ap("")
    ap("| property | pw | pw_eg5 | pw_hybrid |")
    ap("|----------|----|--------|-----------|")
    keys = [("name", "composition"), ("T_solidus_C", "T_solidus (C)"),
            ("T_liquidus_C", "T_liquidus (C)"), ("rho", "rho (kg/m3)"),
            ("cp_solid", "cp,solid (J/kg-K)"), ("cp_liquid", "cp,liquid (J/kg-K)"),
            ("k_solid", "k,solid (W/m-K)"), ("k_liquid", "k,liquid (W/m-K)"),
            ("latent_heat", "L (kJ/kg)"), ("volumetric_latent_heat",
                                          "rho*L (MJ/m3)")]
    for attr, label in keys:
        vals = []
        for cid in ["pw", "pw_eg5", "pw_hybrid"]:
            res = results.get(cid)
            if res is None or res.pcm_props is None:
                vals.append("--")
                continue
            p = res.pcm_props
            v = getattr(p, attr)
            if attr == "name":
                v = ", ".join(f"{k}:{v:.3g}" for k, v in p.composition.items())
            elif attr == "latent_heat":
                v = v / 1e3
            elif attr == "volumetric_latent_heat":
                v = v / 1e6
            vals.append(f"{v:.4g}" if isinstance(v, (int, float)) else str(v))
        ap(f"| {label} | " + " | ".join(vals) + " |")
    ap("")

    ap("## 3. Key thermal metrics")
    ap("")
    ap(_df_to_markdown(metrics))
    ap("")
    ap("*(ppm = parts per million; the energy closure column is the relative")
    ap("energy-balance error of the discretised scheme and should be near")
    ap("machine precision, confirming exact discrete conservation.)*")
    ap("")

    ap("## 4. Figures")
    ap("")
    for fig in ["fig1_cell_temperature.png", "fig2_melt_fraction.png",
                "fig3_metrics.png", "fig4_radial_profiles.png",
                "fig5_rz_contours.png"]:
        if (outdir / fig).exists():
            ap(f"![{fig}]({fig})")
            ap("")

    ap("## 5. Discussion (auto-generated)")
    ap("")
    bare = results.get("bare")
    pw = results.get("pw")
    eg = results.get("pw_eg5")
    hy = results.get("pw_hybrid")

    if bare is not None and pw is not None:
        dT = bare.peaks["T_cell_max"] - pw.peaks["T_cell_max"]
        ap(f"**Effect of the PCM jacket.** With natural convection only, the "
           f"cell peaks at {bare.peaks['T_cell_max']:.1f} degC (max) / "
           f"{bare.peaks['T_cell_mean']:.1f} degC (mean) at {t_amb_C:.0f} degC "
           f"ambient. Adding the base paraffin jacket holds the cell to "
           f"{pw.peaks['T_cell_max']:.1f} degC, a reduction of {dT:.1f} K, "
           f"because most of the generated heat is absorbed as latent heat "
           f"near the melting range while the jacket surface stays close to "
           f"the phase-change temperature. The bare cell also spends "
           f"{metrics.loc['bare', f'time above {t_max_C:.0f} C, max (min)']:.0f} min "
           f"above the {t_max_C:.0f} degC limit versus "
           f"{metrics.loc['pw', f'time above {t_max_C:.0f} C, max (min)']:.0f} min "
           f"with the PCM jacket.")
        ap("")
    if pw is not None and eg is not None:
        ap(f"**Effect of expanded graphite.** Dispersing "
           f"{results['pw_eg5'].pcm_props.composition.get('expanded_graphite', 0)*100:.0f} wt% EG "
           f"raises the composite conductivity from "
           f"{pw.pcm_props.k_solid:.2f} to {eg.pcm_props.k_solid:.2f} W/m-K. "
           f"The cell peak changes from {pw.peaks['T_cell_max']:.2f} to "
           f"{eg.peaks['T_cell_max']:.2f} degC and the PCM absorbs "
           f"{eg.energy['E_latent_J']/1e3:.2f} kJ latent heat vs "
           f"{pw.energy['E_latent_J']/1e3:.2f} kJ for the base wax, showing "
           f"more uniform temperature spreading and better utilisation of "
           f"the jacket volume at equal latent capacity (the EG itself "
           f"stores no latent heat, so the composite latent reservoir is "
           f"{(1-eg.pcm_props.composition.get('expanded_graphite', 0))*pw.pcm_props.latent_heat/1e3:.1f} kJ/kg).")
        ap("")
    if pw is not None and hy is not None:
        ap(f"**Effect of the ZnO + h-BN hybrid nanoparticles.** At "
           f"{hy.pcm_props.composition.get('zno',0)*100:.1f} wt% ZnO + "
           f"{hy.pcm_props.composition.get('hbn',0)*100:.1f} wt% h-BN the "
           f"effective-medium models predict a modest conductivity increase "
           f"({pw.pcm_props.k_solid:.3f} -> {hy.pcm_props.k_solid:.3f} W/m-K, "
           f"{(hy.pcm_props.k_solid/pw.pcm_props.k_solid-1)*100:+.1f}%), which "
           f"translates into a small reduction of the cell peak "
           f"({pw.peaks['T_cell_max']:.2f} -> {hy.peaks['T_cell_max']:.2f} degC). "
           f"This is consistent with the physics of dilute dispersions: "
           f"below about 1 vol% no percolating conductive network forms, so "
           f"hybrid nanoparticle PCMs mainly help through slightly improved "
           f"heat spreading and heat capacity, whereas percolating EG "
           f"networks change the conductivity by an order of magnitude. "
           f"Reported larger enhancements in the hybrid-nano-PCM literature "
           f"involve agglomerated networks; those can be explored by raising "
           f"the loadings or the Nielsen shape parameter in "
           f"`config.json`.")
        ap("")

    ap("## 6. Energy balance summary")
    ap("")
    ap("| case | generated (kJ) | to ambient (kJ) | stored (kJ) | latent used (kJ) | closure (ppm) |")
    ap("|------|----------------|-----------------|-------------|------------------|---------------|")
    for cid, res in results.items():
        e = res.energy
        ap(f"| `{cid}` | {e['E_generated_J']/1e3:.3f} | {e['E_to_ambient_J']/1e3:.3f} "
           f"| {e['E_stored_J']/1e3:.3f} | "
           f"{(e['E_latent_J']/1e3) if res.has_pcm else 0:.3f} "
           f"| {abs(e['closure_rel'])*1e6:.2e} |")
    ap("")

    ap("## 7. Model assumptions (see README for full details)")
    ap("")
    ap("- Conduction-only PCM model; melt convection approximated by an")
    ap("  enhanced liquid conductivity (factor configurable).")
    ap("- Uniform volumetric heat generation in the jelly roll; SOC-dependent")
    ap("  internal resistance and entropic term from editable lookup tables.")
    ap("- Perfect thermal contact cell/PCM (contact resistance configurable).")
    ap("- Thin aluminium enclosure treated as a lumped conductance (Bi << 0.1).")
    ap("- Natural convection: Churchill-Chu correlation for a horizontal")
    ap("  cylinder; radiation linearised per face (eps = configurable).")
    ap("- Constant ambient temperature; no cell electrochemistry coupling")
    ap("  beyond the thermal feedback on the entropic term.")
    ap("")

    p = outdir / "report.md"
    p.write_text("\n".join(L), encoding="utf-8")
    return p
