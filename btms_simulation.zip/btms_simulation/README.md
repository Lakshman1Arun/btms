# btms_sim — Battery Thermal Management System (BTMS) Simulation

Transient 3-D thermal simulation of a cylindrical Li-ion cell with **passive
phase-change-material (PCM) thermal management**, comparing four cooling
configurations at 2C discharge in a 40 °C hot climate:

| case | configuration |
|------|---------------|
| `bare` | no fins, no PCM — natural convection + radiation only (baseline) |
| `pw` | base paraffin wax (PW) PCM jacket |
| `pw_eg5` | PW + **5 wt% expanded graphite (EG)** composite jacket |
| `pw_hybrid` | PW + **ZnO + h-BN hybrid nanoparticle** composite jacket |

Built with standard engineering libraries: **NumPy** (solver kernels),
**SciPy** (physical constants), **pandas** (data), **Matplotlib** (figures),
**pytest** (verification). The thermal core is an explicit finite-difference
**enthalpy method** on a structured cylindrical *(r, θ, z)* grid with adaptive
time stepping — energy-conserving to machine precision (verified).

---

## 1. Physical model

### 1.1 Geometry

```
        z
        ^      +----------------+   _
        |      |   end cap      |  /
        |      |  (convection)  | /  cell:  Ø18 mm x 65 mm
        |      +----+----+------+   PCM jacket: 10 mm annulus
        |      |####|    |######|   enclosure: 0.5 mm Al sleeve (lumped)
   65 mm|      |cell|    |######|
        |      |source |  |######|   #### = PCM region
        |      |####|    |######|
        |      +----+----+------+
        |      |   end cap      |
        +------+----------------+--> r
               |---- 18 mm -----|
               |------ 38 mm -------|
```

- **Cell:** Samsung INR18650-25R, 2.5 Ah NMC — uniform volumetric heat
  generation in the cell region, anisotropic conductivity
  (`k_r = k_θ = 2.0`, `k_z = 25.0 W/m·K`, typical jelly-roll values).
- **PCM jacket:** 10 mm annular sleeve; optional thin aluminium enclosure
  treated as a lumped conductance (Bi = h·t/k ≈ 2·10⁻⁴ ≪ 0.1, so the wall
  is isothermal through its thickness and does not need meshing).
- Grid: 12 cell + 10 PCM radial rings × 12 θ × 27 z = **7 128 nodes**.

### 1.2 Battery heat generation

Coulomb-counting SOC with SOC-dependent ohmic resistance and entropic
(reversible) term — both supplied as **editable lookup tables**:

```
Q(t) = I²·R(SOC)  −  I·T_cell·(dU/dT)(SOC)      during CC discharge
Q(t) = 0                                         during rest
I   = C-rate × capacity                          (= 5 A at 2C / 2.5 Ah)
```

Default tables represent an NMC 18650 (`R₀ = 28 mΩ`, rising ~45 % at
end-of-discharge; entropic coefficient −60…+150 µV/K across SOC). At 2C this
yields ≈ 0.6–0.9 W, peaking at end of discharge — consistent with published
25R data. The cell temperature feeds back into the entropic term each step.
A constant-`Q` override (`operating.q_constant_W`) is available for
verification studies.

### 1.3 Enthalpy-method PCM treatment

Phase change is handled with the standard **enthalpy formulation**
(Voller 1987; Voller & Swaminathan 1991). Each node carries an enthalpy

```
H(T) = ρ·cp_s·(T − T_ref) + ρ·L·f(T) + (ρ·cp_l − ρ·cp_s)·max(T − T_liq, 0)
f(T) = clip((T − T_sol)/(T_liq − T_sol), 0, 1)          (melt fraction)
```

piecewise-linear and **exactly invertible**, so each explicit step

```
H_new = H_old + (Δt/V)·[ Σ_faces G·(T_nb − T) + Σ_bnd h·A·(T_∞ − T) + Q'''·V ]
T_new = T⁻¹(H_new)
```

conserves energy to machine precision — this is verified by the test suite,
not assumed. The mushy range (solidus 43 °C, liquidus 46 °C) mimics the
melting spread of commercial RT44HC-class paraffin.

**Interface treatment.** Face conductances use the series-resistance
(harmonic-mean) form `G = A/(d₁/k₁ + d₂/k₂ + R_c)`, the correct treatment at
cell/PCM interfaces and everywhere else. An optional thermal contact
resistance `R_c` is configurable.

**Melt convection.** The conduction-only PCM model is corrected for buoyant
convection inside the melt with an enhanced liquid conductivity
(`k_liq,eff = k_liq × 1.5`, editable) — a standard practical surrogate that
keeps the model robust while capturing the acceleration of melt-front
propagation.

### 1.4 Composite property models (mixing rules)

All composite properties are **computed in code from editable base-material
data** — no hardcoded composite values:

| constituent | model applied |
|-------------|---------------|
| ZnO nanoparticles (near-spherical) | **Maxwell–Eucken** (Maxwell 1873) |
| h-BN platelets (high aspect ratio) | **Lewis–Nielsen** (Lewis & Nielsen 1970), `A = 8`, `φ_m = 0.64` |
| EG flakes (percolating network) | **calibrated interpolation** of published PW/EG measurements (see below) |
| density | inverse-volume rule of mixtures: `1/ρ = Σ wᵢ/ρᵢ` |
| specific heat | mass-fraction rule of mixtures: `cp = Σ wᵢ·cpᵢ` |
| latent heat | wax mass fraction only: `L = (1 − Σ w_fillers)·L_pw` |

The hybrid case applies Maxwell–Eucken (ZnO) and then Lewis–Nielsen (h-BN)
*sequentially* on the evolving effective medium — the standard approach for
hybrid nanofluids/nano-PCMs.

**Why EG uses a calibration curve.** Isotropic effective-medium theories
(Maxwell, Bruggeman, Hamilton–Crosser) badly underestimate percolating
graphite networks, which form conductive skeletons rather than dilute
inclusions. The composite conductivity is therefore interpolated from
published PW/EG measurements, anchored at **0 / 1 / 2 / 5 / 10 wt% → 0.20 /
0.85 / 1.8 / 4.5 / 11.0 W/m·K** (Mills & Al-Hallaj 2005; Şarı 2004; Zhong et
al. 2010). The anchors are plain arrays in `config.json` — replace them with
your own measurements in seconds.

**Computed effective properties (defaults):**

| property | PW | PW + 5 wt% EG | PW + 1 wt% ZnO + 1 wt% h-BN |
|----------|----|---------------|------------------------------|
| ρ (kg/m³) | 830 | 856.7 | 842.4 |
| cp,solid (J/kg·K) | 2000 | 1936 | 1972 |
| cp,liquid (J/kg·K) | 2200 | 2126 | 2168 |
| k,solid (W/m·K) | 0.200 | **4.500** | 0.208 |
| k,liquid (W/m·K) | 0.170 | 3.825 | 0.177 |
| L (kJ/kg) | 210 | 199.5 | 205.8 |
| ρ·L (MJ/m³) | 174.3 | 170.9 | 173.4 |

Note the physics: 5 wt% EG boosts conductivity **22×** while costing only
~2 % of the latent reservoir, whereas 2 wt% of dilute hybrid nanoparticles
gives a modest +4 % in `k` (no percolation below ~1 vol%) — this is exactly
the behaviour the simulation reproduces in the final comparison.

### 1.5 Boundary conditions

- **Convection:** Churchill–Chu (1975) correlation for a horizontal cylinder
  with film-temperature air properties (interpolated table), or a
  user-set constant `h`.
- **Radiation:** linearised per exterior face,
  `h_rad = ε·σ·(T_s+T_∞)(T_s²+T_∞²)`, `ε = 0.85` default — at these
  temperatures radiation contributes roughly as much as natural convection
  and must not be neglected.
- **Series resistance per face:** half-cell conduction + convection +
  radiation + enclosure wall.
- **Axis:** symmetry (zero-area wedge faces on the axis).
- **End caps:** convect like the barrel (cell terminals); can be made
  adiabatic per case via `options: {"insulated_ends": true}` (used by the
  analytical verification test).

### 1.6 Time stepping

Adaptive explicit stepping at `Δt = CFL · Δt_stable` with

```
Δt_stable = min_nodes( ρ·cp_min·V / Σ G_faces )
```

(conservative: the latent-heat addition in the mushy zone only *increases*
effective capacity), clamped by `dt_max`, a 1.2× per-step growth limit, and
the next output event. Typical production run: ~10⁵ steps per case,
5–6 min for all four cases on a desktop CPU, pure NumPy.

---

## 2. Standard material properties (all editable in `config.json`)

Base values are *standard handbook/literature data* for each material; edit
them directly in the `materials` block — no code changes needed.

| material | property | value | source |
|----------|----------|-------|--------|
| Paraffin wax (RT44HC-class) | solidus / liquidus | 43 / 46 °C | Rubitherm RT44HC datasheet class |
| | ρ solid / liquid / eff. | 880 / 760 / 830 kg/m³ | datasheet + volume-average |
| | cp solid / liquid | 2000 / 2200 J/kg·K | typical paraffin |
| | k solid / liquid | 0.20 / 0.17 W/m·K | typical paraffin |
| | latent heat L | 210 kJ/kg | datasheet-class |
| Expanded graphite | ρ, cp, k_intrinsic | 2200 kg/m³, 710 J/kg·K, 2000 W/m·K | Mills & Al-Hallaj 2005 |
| | composite k anchors | see §1.4 | Mills & Al-Hallaj 2005; Şarı 2004; Zhong 2010 |
| ZnO nanoparticles | ρ, cp, k | 5600 kg/m³, 490 J/kg·K, 50 W/m·K | standard oxide data |
| h-BN platelets | ρ, cp, k | 2200 kg/m³, 750 J/kg·K, 300 W/m·K | in-plane dominated random-platelet effective value |
| | aspect ratio, Nielsen A, φ_max | 50, 8.0, 0.64 | platelet geometry parameters |

Cell (Samsung INR18650-25R): 18 mm × 65 mm, 45 g, 2.5 Ah, cp = 1050 J/kg·K
(effective), anisotropic k as above. Boundary: 40 °C ambient, ε = 0.85.

---

## 3. Installation

```bash
# Python 3.10+ recommended
pip install -r requirements.txt        # numpy, scipy, pandas, matplotlib, pytest
```

No compiled dependencies, no GPU, no installation of the package itself
(required version of every library is intentionally modest).

## 4. Quickstart

```bash
# run the full comparison study (writes results/ ; ~5-6 min)
python -m btms_sim

# options
python -m btms_sim --config config.json --outdir results
python -m btms_sim --cases bare pw_eg5          # subset of cases
python -m btms_sim --version

# run the verification suite first (recommended; ~2.5 min)
python -m pytest tests/ -v
```

Everything the model *needs* lives in **`config.json`** — geometry, material
data, mixing-rule parameters, load profile, ambient conditions, numerics,
and the case list. Typical what-if edits:

- change loading: `composites.pw_eg.eg_wt_pct` → `8.0`
- change ambient / initial temperature: `operating.ambient_C`, `initial_C`
- different C-rate: `operating.c_rate` (current and duration follow automatically)
- thicker jacket: `pcm_jacket.thickness_mm`
- add contact resistance: `pcm_jacket.contact_resistance_m2K_W`
- adiabatic-ish comparison: `operating.emissivity` → `0`, `h_mode` → `constant`

## 5. Configuration reference (`config.json`)

| block | key | meaning |
|-------|-----|---------|
| `cell` | `diameter_mm`, `length_mm`, `mass_kg`, `capacity_Ah`, `cp_J_kgK` | cell geometry & thermal mass (ρ computed from m/V) |
| | `k_radial/theta/axial_W_mK` | anisotropic jelly-roll conductivity |
| `battery` | `r0_ref_ohm`, `soc_points`, `r_multiplier_points`, `du_dt_points_V_K` | SOC lookup tables (ascending SOC) |
| `pcm_jacket` | `thickness_mm`, `contact_resistance_m2K_W`, `enclosure_*` | jacket geometry & interface |
| `materials.*` | … | base-material data of §2 |
| `composites` | `pw_eg.eg_wt_pct`, `pw_hybrid.{zno,hbn}_wt_pct` | filler loadings (wt%) |
| `operating` | `c_rate`, `ambient_C`, `initial_C` | electrical & thermal environment |
| | `h_mode` | `churchill_chu` correlation or `constant` |
| | `h_constant_W_m2K`, `emissivity`, `k_liquid_enhancement` | BC & melt-convection parameters |
| | `q_constant_W` | constant-heat override (null = battery model) |
| `numerics` | `nr_cell`, `nr_pcm`, `n_theta`, `nz` | grid resolution (r × θ × z) |
| | `cfl`, `dt_min_s`, `dt_max_s`, `dt_growth` | adaptive time-step control |
| `runtime` | `discharge_s`, `rest_s`, `sample_every_s`, `snapshot_times_s` | schedule |
| `limits` | `t_max_C` | temperature limit used in metrics (45 °C) |
| `cases` | `id`, `label`, `pcm_type` | study matrix (`none`/`pure`/`pw_eg`/`pw_hybrid`) |

Configuration is validated at load time (physical ranges, ascending tables,
valid case types) so a typo fails fast with a readable message.

## 6. Outputs (`results/`)

| file | content |
|------|---------|
| `timeseries_<case>.csv` | t, SOC, Q_gen, T_cell mean/max/surface, T_outer, melt fraction (volume-avg), cumulative energies, running energy closure |
| `fig1_cell_temperature.png` | cell mean & max temperature histories, all cases + limit lines |
| `fig2_melt_fraction.png` | volume-averaged melt fraction, PCM cases, EOD annotations |
| `fig3_metrics.png` | 2×2 metric comparison bars |
| `fig4_radial_profiles.png` | mid-plane radial temperature profiles at snapshot times |
| `fig5_rz_contours.png` | θ-averaged (r, z) temperature fields at end of discharge |
| `report.md` | auto-generated report: properties, metrics table, figures, discussion, energy balance |

## 7. Verification & test results

**37/37 tests pass** — see **[`TEST_RESULTS.md`](TEST_RESULTS.md)** for the
full report. Highlights:

- **Energy conservation:** `E_gen − E_out = ΔU` closes to ~1e-15 relative on
  every configuration (adiabatic and cooled), latent path included.
- **Analytical steady state:** matches the classic cylinder solution
  `T(r) = T_∞ + q'''(R²−r²)/(4k_r) + q'''R/(2h)` within 2 %.
- **Grid & time-step independence:** peak temperature changes < 0.2 K between
  coarse and fine meshes; melt energy within 5 %.
- **Axisymmetry:** the 3-D kernel preserves rotational symmetry to < 1e-6 K
  (validates the θ-bookkeeping for future non-symmetric extensions).
- **Property/battery/geometry unit tests:** limits, monotonicity, bounds,
  volume closure, SOC & heat-generation identities.

## 8. Headline results (2C discharge, 40 °C ambient, default config)

| metric | bare | PW | PW+5%EG | PW+hybrid |
|--------|------|----|---------|-----------|
| peak cell max T (°C) | **53.5** | 45.3 | **43.8** | 45.2 |
| time above 45 °C, cell max (min) | 33.2 | 7.1 | **0.0** | 6.1 |
| melt fraction at EOD (vol %) | — | 6.0 | 5.1 | 6.0 |
| latent energy used (kJ) | — | 0.52 | 0.35 | 0.52 |
| energy to ambient (kJ) | 1.02 | 0.39 | 0.57 | 0.39 |

**Reading the numbers**

- The PCM jackets cut the peak cell temperature by **8.2 K** (PW) and
  **9.7 K** (PW+EG) and hold the cell near the melting plateau; the bare
  cell spends the whole second half of discharge above the 45 °C limit.
- **EG is the strongest performer**: its 22× conductivity spreads heat
  through the jacket, lowering both the peak (43.8 °C) and the time above
  the limit (zero), while rejecting more heat to ambient *during* discharge.
- **The hybrid nano-PCM tracks base PW closely** (ΔT_peak ≈ 0.05 K): at
  ~1 vol% total there is no percolating network, so conductivity rises only
  ~4 % and the melt curves nearly overlap. This is the *expected* physics of
  dilute dispersions — studies reporting much larger hybrid gains involve
  agglomerated/percolated networks; you can explore that regime by raising
  the loadings or the Nielsen `A` parameter in `config.json`.
- At 2C the jacket uses only ~5–6 % of its latent reservoir, i.e. the PCM is
  comfortably sized for this load — the sizing margin is itself a useful
  design output (see `pcm_jacket.thickness_mm`).

## 9. Model assumptions & limitations

1. **Conduction-only PCM** with enhanced-liquid-`k` melt-convection
   surrogate — no resolved buoyancy (conservative for melt-front timing).
2. **Uniform volumetric heat generation** in the cell (jelly-roll average);
   SOC-dependent `R` and entropic term from editable tables, not a full
   electrochemical model.
3. **Perfect cell/PCM contact** by default (contact resistance configurable,
   verified in tests).
4. **Thin-wall lumping** of the enclosure (Bi ≪ 0.1); end caps convect like
   the barrel.
5. **Constant ambient**; radiation linearised per face (excellent
   approximation for ΔT ≲ 40 K at these temperatures).
6. Coulomb-counting SOC at rated capacity (no Peukert/fade at 2C —
   conservative for heat generation).
7. PCM subcooling and volume-change (void formation) on solidification are
   neglected; properties are phase-independent except `k` and `cp`.

## 10. Extending the study

- **Fins / fin-PCM hybrids:** the θ-direction machinery is fully general
  (non-axisymmetric conductances, per-face bookkeeping) — add fin nodes as a
  third material with high `k`, vary `h` or source around θ.
- **Other PCMs:** edit `materials.paraffin` (or add new blocks + case types
  in `properties.py`, one ~20-line builder each).
- **Measured composites:** replace the EG anchors / mixing rules with your
  own data; everything else follows.
- **Different cells:** change `cell` + `battery` tables (works for 21700,
  pouches with a Cartesian adapter, etc.).

## 11. Project structure

```
btms_simulation/
├── config.json                  # ALL model inputs (editable)
├── requirements.txt
├── README.md                    # this file
├── TEST_RESULTS.md              # verification report (37/37 passed)
├── conftest.py                  # pytest bootstrap + shared fixtures
├── btms_sim/
│   ├── __init__.py
│   ├── __main__.py              # python -m btms_sim
│   ├── config.py                # load + validate + overrides
│   ├── properties.py            # mixing models & composite builders
│   ├── battery.py               # SOC-dependent heat generation
│   ├── geometry.py              # cylindrical grid & conductance bookkeeping
│   ├── solver.py                # 3-D enthalpy-method FDM solver
│   ├── postprocess.py           # metrics, CSV, plots, report.md
│   └── main.py                  # orchestration & CLI
├── tests/
│   ├── test_properties.py       # mixing-model unit tests
│   ├── test_battery.py          # heat-generation tests
│   ├── test_geometry.py         # grid integrity tests
│   ├── test_solver.py           # conservation, analytical, symmetry tests
│   ├── test_grid_independence.py
│   └── test_postprocess.py      # pipeline smoke test
└── results/                     # generated: CSVs, 5 figures, report.md
```

## 12. References

1. Voller, V.R. (1987). *A fixed-grid numerical modelling methodology for
   convection–diffusion mushy region phase-change problems.* Int. J. Heat
   Mass Transfer 30(8), 1709–1719.
2. Voller, V.R. & Swaminathan, C.R. (1991). *General source-based method for
   solidification phase change.* Numer. Heat Transfer B 19(2), 175–189.
3. Mills, A. & Al-Hallaj, S. (2005). *Simulation of passive thermal
   management system for lithium-ion battery packs.* J. Power Sources
   141(2), 307–315.
4. Şarı, A. (2004). *Form-stable paraffin/high density polyethylene
   composites as solid–liquid phase change material for thermal energy
   storage.* Energy Convers. Manage. 45, 2033–2042.
5. Zhong, Y. et al. (2010). *Thermal conductivity enhancement of paraffin
   wax using expanded graphite.* J. Univ. Sci. Technol. Beijing 17, 226.
6. Maxwell, J.C. (1873). *A Treatise on Electricity and Magnetism,* Clarendon
   Press (Maxwell–Eucken effective medium).
7. Lewis, T. & Nielsen, L. (1970). *Dynamic mechanical and rheological
   properties of filled systems.* J. Appl. Polym. Sci. 14, 1449–1471
   (Lewis–Nielsen model).
8. Churchill, S.W. & Chu, H.H.S. (1975). *Correlating equations for laminar
   and turbulent free convection from a horizontal cylinder.* Int. J. Heat
   Mass Transfer 18(9), 1049–1053.
9. Bergman, T.L. et al. *Fundamentals of Heat and Mass Transfer,* 8th ed.,
   Wiley (air property tables, harmonic-mean interface conductances).
10. Rao, Z. & Wang, S. (2011). *A review of power battery thermal energy
    management.* Renewable & Sustainable Energy Reviews 15, 4554–4571.
