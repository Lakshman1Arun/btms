"""Geometric integrity tests for the cylindrical FDM grid."""

import numpy as np
import pytest

from btms_sim.geometry import build_grid

PI = np.pi


def _volumes(grid):
    return grid.V_flat


# --------------------------------------------------------------------------- #
def test_total_volume_bare(base_cfg):
    g = build_grid(base_cfg, has_pcm=False)
    cell = base_cfg["cell"]
    R = cell["diameter_mm"] * 0.5e-3
    L = cell["length_mm"] * 1e-3
    assert _volumes(g).sum() == pytest.approx(PI * R**2 * L, rel=1e-9)
    assert g.V_cell == pytest.approx(PI * R**2 * L, rel=1e-9)
    assert g.V_pcm == pytest.approx(0.0)


def test_total_volume_with_pcm(base_cfg):
    g = build_grid(base_cfg, has_pcm=True)
    cell = base_cfg["cell"]
    jack = base_cfg["pcm_jacket"]
    R = cell["diameter_mm"] * 0.5e-3
    L = cell["length_mm"] * 1e-3
    t = jack["thickness_mm"] * 1e-3
    assert _volumes(g).sum() == pytest.approx(PI * (R + t) ** 2 * L, rel=1e-9)
    assert g.V_cell == pytest.approx(PI * R**2 * L, rel=1e-6)
    assert g.V_pcm == pytest.approx(PI * ((R + t) ** 2 - R**2) * L, rel=1e-6)


def test_boundary_face_areas(base_cfg):
    g = build_grid(base_cfg, has_pcm=True)
    L = base_cfg["cell"]["length_mm"] * 1e-3
    n_outer = int((g.bnd_kind == 0).sum())
    outer_area = g.bnd_A[g.bnd_kind == 0].sum()
    end_area = g.bnd_A[g.bnd_kind == 1].sum()
    assert outer_area == pytest.approx(2 * PI * g.r_out * L, rel=1e-9)
    assert end_area == pytest.approx(2 * PI * g.r_out**2, rel=1e-9)
    assert n_outer == g.n_theta * g.nz


def test_conductance_arrays_positive_finite(base_cfg):
    g = build_grid(base_cfg, has_pcm=True)
    for A, d1, d2, rex in [(g.A_r, g.d1_r, g.d2_r, g.rex_r),
                           (g.A_t, g.d1_t, g.d2_t, g.rex_t),
                           (g.A_z, g.d1_z, g.d2_z, g.rex_z)]:
        assert np.all(A > 0) and np.all(np.isfinite(A))
        assert np.all(d1 > 0) and np.all(d2 > 0)
        assert np.all(rex >= 0)


def test_contact_resistance_assigned(base_cfg):
    from btms_sim.config import apply_overrides
    cfg = apply_overrides(base_cfg, {"pcm_jacket":
                                     {"contact_resistance_m2K_W": 5e-4}})
    g = build_grid(cfg, has_pcm=True)
    ncz = cfg["numerics"]["n_theta"] * cfg["numerics"]["nz"]
    iface = slice((cfg["numerics"]["nr_cell"] - 1) * ncz,
                  cfg["numerics"]["nr_cell"] * ncz)
    assert np.all(g.rex_r[iface] == 5e-4)
    assert np.all(np.delete(g.rex_r, np.arange(iface.start, iface.stop)) == 0.0)


def test_theta_symmetry_of_volumes(base_cfg):
    g = build_grid(base_cfg, has_pcm=True)
    v3 = g.V_flat.reshape(g.shape)
    assert np.allclose(v3, np.roll(v3, 1, axis=1), rtol=0, atol=0)


def test_neighbor_index_symmetry(base_cfg):
    """Every interior face must appear consistently: sum of 'a' roles equals
    sum of 'b' roles over the node set (flux bookkeeping consistency)."""
    g = build_grid(base_cfg, has_pcm=True)
    for ia, ib in [(g.ia_r, g.ib_r), (g.ia_t, g.ib_t), (g.ia_z, g.ib_z)]:
        assert np.all(ia != ib)
        assert ia.max() < g.nr * g.n_theta * g.nz
        assert ib.max() < g.nr * g.n_theta * g.nz
