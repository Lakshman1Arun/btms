"""Sanity / monotonicity tests for the effective-property mixing models."""

import numpy as np
import pytest

from btms_sim.properties import (build_pcm_properties, lewis_nielsen,
                                 mass_to_volume_fractions, maxwell_eucken)


# --------------------------------------------------------------------------- #
#  Maxwell-Eucken
# --------------------------------------------------------------------------- #
def test_maxwell_limits():
    assert maxwell_eucken(0.2, 50.0, 0.0) == pytest.approx(0.2)
    # phi -> 1 recovers (approximately) the particle conductivity
    assert maxwell_eucken(0.2, 50.0, 0.999) > 40.0


def test_maxwell_monotonic_and_bounded():
    ks = [maxwell_eucken(0.2, 50.0, phi) for phi in np.linspace(0, 0.5, 25)]
    assert all(b >= a for a, b in zip(ks, ks[1:]))          # monotonic up
    assert all(0.2 <= k <= 50.0 for k in ks)                # Hashin bounds


def test_maxwell_symmetric_reversal():
    """Swapping matrix/particle with the SAME volume fraction keeps the
    model self-consistent (k_eff must move toward the majority phase)."""
    k_dilute_particle = maxwell_eucken(0.2, 50.0, 0.01)
    assert k_dilute_particle < 0.25         # dilute spheres barely help


# --------------------------------------------------------------------------- #
#  Lewis-Nielsen
# --------------------------------------------------------------------------- #
def test_nielsen_limits():
    assert lewis_nielsen(0.2, 300.0, 0.0, 8.0, 0.64) == pytest.approx(0.2)


def test_nielsen_shape_enhances_for_platelets():
    """For k_p >> k_m a larger geometry parameter A (platelet-like) gives a
    stronger enhancement than spheres (A = 2) at the same loading."""
    k_sphere = lewis_nielsen(0.2, 300.0, 0.01, 2.0, 0.64)
    k_platelet = lewis_nielsen(0.2, 300.0, 0.01, 8.0, 0.64)
    assert k_platelet > k_sphere > 0.2


def test_nielsen_phi_max_guard():
    with pytest.raises(ValueError):
        lewis_nielsen(0.2, 300.0, 0.7, 8.0, 0.64)


# --------------------------------------------------------------------------- #
#  Composite builders
# --------------------------------------------------------------------------- #
def test_mass_to_volume_fractions():
    phi = mass_to_volume_fractions({"a": 0.5, "b": 0.5}, {"a": 1000., "b": 2000.})
    assert phi["a"] == pytest.approx(2.0 / 3.0)
    assert sum(phi.values()) == pytest.approx(1.0)


def test_eg_composite_properties(base_cfg):
    pw = build_pcm_properties(base_cfg, "pure")
    eg = build_pcm_properties(base_cfg, "pw_eg")
    w = base_cfg["composites"]["pw_eg"]["eg_wt_pct"] / 100.0

    assert eg.k_solid > pw.k_solid * 10          # percolating graphite boost
    assert eg.latent_heat == pytest.approx((1 - w) * pw.latent_heat, rel=1e-9)
    assert eg.rho > pw.rho                       # graphite is denser
    assert eg.cp_solid < pw.cp_solid             # graphite cp is lower
    assert eg.T_solidus_C == pw.T_solidus_C      # mp unchanged
    assert 0.0 < eg.volumetric_latent_heat < 3e8  # J/m3 sanity


def test_hybrid_composite_properties(base_cfg):
    pw = build_pcm_properties(base_cfg, "pure")
    hy = build_pcm_properties(base_cfg, "pw_hybrid")

    # modest conductivity increase (no percolation at ~1 wt%)
    assert 1.0 < hy.k_solid / pw.k_solid < 1.5
    # latent heat scales with wax mass fraction
    w_particles = (base_cfg["composites"]["pw_hybrid"]["zno_wt_pct"]
                   + base_cfg["composites"]["pw_hybrid"]["hbn_wt_pct"]) / 100.0
    assert hy.latent_heat == pytest.approx((1 - w_particles) * pw.latent_heat,
                                           rel=1e-9)
    assert hy.rho > pw.rho
    assert 0.0 < hy.k_solid < 1.0                # stays wax-dominated


def test_eg_k_interpolates_anchors(base_cfg):
    eg_mat = base_cfg["materials"]["expanded_graphite"]
    cfg = {**base_cfg,
           "composites": {"pw_eg": {"eg_wt_pct": 2.0}}}
    comp = build_pcm_properties(cfg, "pw_eg")
    assert comp.k_solid == pytest.approx(
        eg_mat["k_composite_anchors_W_mK"][2])   # anchor at 2 wt%


def test_unknown_type_raises(base_cfg):
    with pytest.raises(ValueError):
        build_pcm_properties(base_cfg, "unicorn")
