"""Grid-independence check: refining the mesh must not change the answer
beyond the stated tolerance."""

import numpy as np
import pytest

from btms_sim.config import apply_overrides
from btms_sim.solver import ThermalSolver


def _run(cfg, nr_cell, nr_pcm, nz):
    cfg = apply_overrides(cfg, {
        "numerics": {"nr_cell": nr_cell, "nr_pcm": nr_pcm, "nz": nz},
        # 1200 s of pure-paraffin discharge grows the melt layer to ~8 mm,
        # thicker than the coarse cells, so the melt metric becomes
        # grid-convergent (at 600 s the front is sub-cell and honestly
        # resolution-dependent).
        "runtime": {"discharge_s": 1200.0, "rest_s": 0.0,
                    "sample_every_s": 60.0, "snapshot_times_s": []},
        "cases": [{"id": "case", "label": "case", "pcm_type": "pure"}],
    })
    solver = ThermalSolver(cfg, cfg["cases"][0])
    return solver.run()


def test_grid_independence_pcm_case(base_cfg):
    coarse = _run(base_cfg, nr_cell=8, nr_pcm=5, nz=9)
    fine = _run(base_cfg, nr_cell=16, nr_pcm=10, nz=18)

    d_peak = abs(coarse.peaks["T_cell_mean"] - fine.peaks["T_cell_mean"])
    d_latent = abs(coarse.energy["E_latent_J"] - fine.energy["E_latent_J"])

    assert d_peak < 0.5, (
        f"peak cell mean T differs by {d_peak:.3f} K between grids")
    # latent absorption should agree within ~8 % of the finer value
    assert fine.energy["E_latent_J"] > 0
    assert d_latent / fine.energy["E_latent_J"] < 0.08
    # both runs must remain energy-conservative
    assert abs(coarse.energy["closure_rel"]) < 1e-10
    assert abs(fine.energy["closure_rel"]) < 1e-10


def test_time_step_independence(base_cfg):
    """Halving dt_max must not change the result beyond sampling noise."""
    cfg_a = apply_overrides(base_cfg, {
        "numerics": {"dt_max_s": 1.0},
        "runtime": {"discharge_s": 600.0, "rest_s": 0.0,
                    "sample_every_s": 30.0, "snapshot_times_s": []},
        "cases": [{"id": "case", "label": "case", "pcm_type": "pure"}],
    })
    cfg_b = apply_overrides(cfg_a, {"numerics": {"dt_max_s": 0.5}})

    ra = ThermalSolver(cfg_a, cfg_a["cases"][0]).run()
    rb = ThermalSolver(cfg_b, cfg_b["cases"][0]).run()
    assert abs(ra.peaks["T_cell_mean"] - rb.peaks["T_cell_mean"]) < 0.1
