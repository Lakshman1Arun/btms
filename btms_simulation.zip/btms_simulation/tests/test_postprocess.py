"""Smoke tests for the post-processing pipeline (metrics, CSVs, report)."""

import pandas as pd

from btms_sim.config import apply_overrides
from btms_sim.postprocess import (compute_metrics_table, export_csvs,
                                  make_plots, write_report)
from btms_sim.solver import ThermalSolver


def _run_all(tmp_path, cfg):
    results = {}
    for case in cfg["cases"]:
        results[case["id"]] = ThermalSolver(cfg, case).run()
    return results


def test_full_postprocess_pipeline(small_cfg, tmp_path):
    cfg = apply_overrides(small_cfg, {"runtime": {"discharge_s": 200.0,
                                                  "rest_s": 40.0}})
    results = _run_all(tmp_path, cfg)
    outdir = tmp_path / "out"

    metrics = compute_metrics_table(results, t_max_C=45.0,
                                    t_eod_s=cfg["runtime"]["discharge_s"])
    assert "peak T_cell max (C)" in metrics.columns
    assert set(metrics.index) == {c["id"] for c in cfg["cases"]}

    csvs = export_csvs(results, outdir)
    assert len(csvs) == len(cfg["cases"])
    df = pd.read_csv(csvs[0])
    assert {"time_s", "T_cell_mean_C", "melt_fraction"} <= set(df.columns)

    figs = make_plots(results, metrics, t_max_C=45.0,
                      t_eod_s=cfg["runtime"]["discharge_s"],
                      t_amb_C=cfg["operating"]["ambient_C"], outdir=outdir)
    assert all(f.exists() for f in figs)

    report = write_report(results, metrics, t_max_C=45.0,
                          t_eod_s=cfg["runtime"]["discharge_s"],
                          t_amb_C=cfg["operating"]["ambient_C"],
                          c_rate=cfg["operating"]["c_rate"],
                          cell_model=cfg["cell"]["model"],
                          pcm_summary_rows=[],
                          grid_summary=results["bare"].grid_summary,
                          outdir=outdir)
    text = report.read_text(encoding="utf-8")
    assert "Results Report" in text and "Energy balance" in text
