"""Solver verification tests.

These are the core physics-verification checks:

1. **Energy conservation (adiabatic box test)** -- with all boundary fluxes
   disabled, the discrete enthalpy scheme must conserve energy to near
   machine precision, including the latent-heat path.
2. **Analytical steady state** -- a bare cell with insulated ends, constant
   heat generation and constant h must reproduce the classical 1-D
   cylindrical solution T(r) = T_amb + q'''(R^2 - r^2)/(4k) + q'''R/(2h).
3. **Axisymmetry** -- the 3-D (r, theta, z) kernel must preserve rotational
   symmetry for axisymmetric problems (validates the theta bookkeeping).
4. **Melt-fraction consistency** -- melt fraction stays in [0, 1] and the
   latent-energy bookkeeping matches the enthalpy field.
5. **Temperature bounds** -- temperatures always stay within physical bounds.
"""

import numpy as np
import pytest

from btms_sim.config import apply_overrides
from btms_sim.solver import ThermalSolver


# --------------------------------------------------------------------------- #
#  1. Energy conservation
# --------------------------------------------------------------------------- #
@pytest.mark.parametrize("pcm_type", ["none", "pure", "pw_eg", "pw_hybrid"])
def test_energy_conservation_adiabatic(small_cfg, pcm_type):
    """Adiabatic box: E_generated must equal Delta U to machine precision."""
    cfg = apply_overrides(small_cfg, {
        "operating": {"h_mode": "constant", "h_constant_W_m2K": 0.0,
                      "emissivity": 0.0, "initial_C": 43.5},
        "cases": [{"id": "case", "label": "case", "pcm_type": pcm_type}],
    })
    solver = ThermalSolver(cfg, cfg["cases"][0])
    res = solver.run()
    e = res.energy
    denom = max(abs(e["E_generated_J"]), 1e-9)
    closure = abs(e["E_generated_J"] - e["E_stored_J"]) / denom
    assert closure < 1e-10, f"energy closure {closure:.3e} for {pcm_type}"


def test_energy_conservation_with_cooling(small_cfg):
    """With convection + radiation the balance E_gen - E_out = Delta U must
    still close exactly (boundary fluxes are part of the scheme)."""
    cfg = apply_overrides(small_cfg, {
        "operating": {"h_mode": "constant", "h_constant_W_m2K": 8.0,
                      "emissivity": 0.6},
        "cases": [{"id": "case", "label": "case", "pcm_type": "pw_eg"}],
    })
    solver = ThermalSolver(cfg, cfg["cases"][0])
    res = solver.run()
    e = res.energy
    # E_to_ambient_J is reported as positive OUT; net INTO domain = -E_out
    balance = e["E_generated_J"] - e["E_to_ambient_J"] - e["E_stored_J"]
    assert abs(balance) / max(e["E_generated_J"], 1e-9) < 1e-10


# --------------------------------------------------------------------------- #
#  2. Analytical steady state (bare cell, insulated ends, constant q)
# --------------------------------------------------------------------------- #
def test_analytical_steady_state(base_cfg):
    cfg = apply_overrides(base_cfg, {
        "operating": {"h_mode": "constant", "h_constant_W_m2K": 10.0,
                      "emissivity": 0.0, "q_constant_W": 1.0},
        "numerics": {"nr_cell": 12, "n_theta": 4, "nz": 3,
                     "dt_max_s": 1.0},
        "runtime": {"discharge_s": 15000.0, "rest_s": 0.0,
                    "sample_every_s": 1000.0, "snapshot_times_s": []},
        "cases": [{"id": "bare_ss", "label": "bare steady state",
                   "pcm_type": "none",
                   "options": {"insulated_ends": True}}],
    })
    solver = ThermalSolver(cfg, cfg["cases"][0])
    res = solver.run()

    g = solver.grid
    q_vol = 1.0 / g.V_cell                    # W/m3
    k_r = base_cfg["cell"]["k_radial_W_mK"]
    h = 10.0
    T_amb = base_cfg["operating"]["ambient_C"]
    R = g.r_c

    def analytical(r):
        return T_amb + q_vol * (R**2 - r**2) / (4.0 * k_r) + q_vol * R / (2.0 * h)

    # final sample = quasi-steady state; compare point values from the
    # final temperature field
    T_center_num = float(np.mean(solver.T.reshape(g.shape)[0, :, :]))
    T_surface_num = float(np.mean(solver.T.reshape(g.shape)[-1, :, :]))

    T_center_ana = analytical(g.rc[0])
    T_surface_ana = analytical(g.rc[-1])

    assert T_center_num == pytest.approx(T_center_ana, rel=0.02), \
        f"centre {T_center_num:.3f} vs analytical {T_center_ana:.3f}"
    assert T_surface_num == pytest.approx(T_surface_ana, rel=0.02), \
        f"surface {T_surface_num:.3f} vs analytical {T_surface_ana:.3f}"

    # independent check on the radial delta (less sensitive to h treatment)
    dT_num = T_center_num - T_surface_num
    dT_ana = q_vol * (R**2 - g.rc[0]**2) / (4.0 * k_r) - \
        q_vol * (R**2 - g.rc[-1]**2) / (4.0 * k_r)
    assert dT_num == pytest.approx(dT_ana, rel=0.05)


# --------------------------------------------------------------------------- #
#  3. Axisymmetry of the 3-D kernel
# --------------------------------------------------------------------------- #
def test_axisymmetry(small_cfg):
    cfg = apply_overrides(small_cfg, {
        "cases": [{"id": "case", "label": "case", "pcm_type": "pure"}],
    })
    solver = ThermalSolver(cfg, cfg["cases"][0])
    solver.run()
    g = solver.grid
    T3 = solver.T.reshape(g.shape)
    deviation = np.max(np.abs(T3 - T3.mean(axis=1, keepdims=True)))
    assert deviation < 1e-6, f"theta-asymmetry {deviation:.3e} K"
    f3 = solver.f.reshape(g.shape)
    dev_f = np.max(np.abs(f3 - f3.mean(axis=1, keepdims=True)))
    assert dev_f < 1e-9


# --------------------------------------------------------------------------- #
#  4. Melt-fraction consistency
# --------------------------------------------------------------------------- #
def test_melt_fraction_consistency(small_cfg):
    """Start inside the mushy zone (43.8 C) and heat: f in [0,1], latent
    energy equals sum(f * rho L V), and f grows monotonically."""
    cfg = apply_overrides(small_cfg, {
        "operating": {"initial_C": 43.8, "h_mode": "constant",
                      "h_constant_W_m2K": 0.0, "emissivity": 0.0},
        "cases": [{"id": "case", "label": "case", "pcm_type": "pure"}],
    })
    solver = ThermalSolver(cfg, cfg["cases"][0])
    assert np.all(solver.f >= 0.0) and np.all(solver.f <= 1.0)
    res = solver.run()
    assert np.all(solver.f >= -1e-12) and np.all(solver.f <= 1.0 + 1e-12)

    g = solver.grid
    latent = float(np.sum(solver.f * solver.cL * g.V_flat))
    assert latent == pytest.approx(res.energy["E_latent_J"], rel=1e-12)
    # latent energy must have grown (net heating) and stay below the total
    # available latent energy of the jacket
    L_total = g.V_pcm * res.pcm_props.rho * res.pcm_props.latent_heat
    assert 0.0 < res.energy["E_latent_J"] <= L_total + 1e-6
    ts = res.timeseries
    assert np.all(np.diff(ts["melt_fraction"].values) >= -1e-12)


# --------------------------------------------------------------------------- #
#  5. Physical temperature bounds
# --------------------------------------------------------------------------- #
def test_temperature_bounds(small_cfg):
    cfg = apply_overrides(small_cfg, {
        "cases": [{"id": "case", "label": "case", "pcm_type": "pw_hybrid"}],
    })
    solver = ThermalSolver(cfg, cfg["cases"][0])
    res = solver.run()
    df = res.timeseries
    T_amb = small_cfg["operating"]["ambient_C"]
    assert (df["T_outer_surface_C"] >= T_amb - 0.5).all()
    assert (df["T_cell_max_C"] < 120.0).all()
    assert (df["T_cell_surface_C"] >= df["T_outer_surface_C"] - 0.5).all()
