"""Tests for the battery heat-generation model."""

import numpy as np
import pytest

from btms_sim.battery import BatteryModel


@pytest.fixture()
def model(base_cfg):
    op = base_cfg["operating"]
    return BatteryModel(
        capacity_Ah=base_cfg["cell"]["capacity_Ah"],
        c_rate=op["c_rate"],
        r0_ref_ohm=base_cfg["battery"]["r0_ref_ohm"],
        soc_points=base_cfg["battery"]["soc_points"],
        r_mult_points=base_cfg["battery"]["r_multiplier_points"],
        du_dt_points=base_cfg["battery"]["du_dt_points_V_K"],
        discharge_s=base_cfg["runtime"]["discharge_s"],
    )


def test_current_and_duration(model):
    # 2C on a 2.5 Ah cell -> 5 A, full discharge in 1800 s
    assert model.I_A == pytest.approx(5.0)
    assert model.t_full_discharge_s == pytest.approx(1800.0)


def test_soc_trajectory(model):
    assert model.soc(0.0) == pytest.approx(1.0)
    assert model.soc(900.0) == pytest.approx(0.5)
    assert model.soc(1800.0) == pytest.approx(0.0)
    assert model.soc(9999.0) == pytest.approx(0.0)   # clamped
    socs = [model.soc(t) for t in np.linspace(0, 1800, 50)]
    assert all(b <= a for a, b in zip(socs, socs[1:]))   # monotonic down


def test_q_positive_during_discharge(model):
    for t in np.linspace(0, 1799, 200):
        q = model.q_gen_W(float(t), 313.15)
        assert q > 0.3, f"non-physical heat rate at t={t}"


def test_q_zero_during_rest(model):
    assert model.q_gen_W(model.discharge_s + 1.0, 313.15) == 0.0


def test_q_matches_constituent_terms(model):
    t, T_K = 720.0, 315.0
    soc = model.soc(t)
    expected = (model.I_A**2 * model.R_internal(soc)
                - model.I_A * T_K * model.du_dt(soc))
    assert model.q_gen_W(t, T_K) == pytest.approx(expected, rel=1e-12)


def test_joule_energy_integral(model):
    """Numeric integral of the Joule term must match the analytic reference
    (the entropic term integrates to a small residual over a full curve)."""
    ts = np.linspace(0, model.t_full_discharge_s, 4001)
    socs = model.soc(ts)
    q_joule = model.I_A**2 * np.interp(socs, model.soc_points,
                                       model.r_mult_points) * model.r0_ref_ohm
    numeric = np.trapezoid(q_joule, ts)
    assert numeric == pytest.approx(model.energy_expected_J(), rel=0.01)


def test_constant_q_override(base_cfg):
    op = base_cfg["operating"]
    m = BatteryModel(
        capacity_Ah=base_cfg["cell"]["capacity_Ah"],
        c_rate=op["c_rate"],
        r0_ref_ohm=base_cfg["battery"]["r0_ref_ohm"],
        soc_points=base_cfg["battery"]["soc_points"],
        r_mult_points=base_cfg["battery"]["r_multiplier_points"],
        du_dt_points=base_cfg["battery"]["du_dt_points_V_K"],
        discharge_s=base_cfg["runtime"]["discharge_s"],
        q_constant_W=1.5,
    )
    assert m.q_gen_W(0.0, 300.0) == 1.5
    assert m.q_gen_W(1234.0, 400.0) == 1.5
    assert m.q_gen_W(m.discharge_s + 0.1, 300.0) == 0.0
