# Test & Verification Report -- btms_sim

**Project:** Passive battery thermal management comparison for a 18650 Li-ion cell
**Test framework:** pytest 9.0.2 | **Python:** 3.12.15 | **Platform:** Linux x86_64
**Test command:** `python -m pytest tests/ -v`

---

## 1. Summary

| metric | value |
|--------|-------|
| Total tests | **37** |
| Passed | **37** |
| Failed / Errors | **0** |
| Total wall time | ~2 min 20 s |
| Energy-balance closure (all runs) | < 1e-13 relative (machine precision) |

The suite covers four independent verification layers: **unit tests** of the
property and battery models, **geometric integrity** of the finite-difference
grid, **physics verification** of the solver against analytical solutions and
conservation laws, and **convergence studies** (grid and time-step
independence). A smoke test exercises the full post-processing pipeline.

---

## 2. What each verification layer proves

### 2.1 Property model tests (`tests/test_properties.py`, 11 tests)

| check | assertion | why it matters |
|-------|-----------|----------------|
| Maxwell-Eucken limits | `k_eff(phi=0) = k_m`, `k_eff(phi=1) -> k_p` | Model reduces to the correct pure-phase limits |
| Maxwell monotonicity & bounds | monotone in `phi`, inside Hashin-Shtrikman bounds | No unphysical conductivity prediction |
| Lewis-Nielsen shape effect | platelet geometry (larger `A`) enhances `k` more than spheres at equal loading | h-BN platelets behave like platelets, not spheres |
| Lewis-Nielsen packing guard | raises `ValueError` when `phi >= phi_max` | Prevents extrapolation beyond model validity |
| EG composite | `k` boost > 10x at 5 wt%, `L = (1-w) L_pw`, denser, lower `cp` | Composite follows the physics of an inert conductive skeleton |
| Hybrid nanocomposite | `1 < k/k_pw < 1.5`, latent heat scaled by wax fraction | Dilute nanoparticles give a modest, honest enhancement |
| EG anchor interpolation | `k(w=2 wt%)` reproduces the configured literature anchor | The editable calibration table is honoured exactly |

### 2.2 Battery model tests (`tests/test_battery.py`, 6 tests)

| check | assertion |
|-------|-----------|
| Rated current & duration | 2C on 2.5 Ah -> 5 A, full discharge in 1800 s |
| SOC trajectory | monotonic, clamped, `SOC(0)=1`, `SOC(1800 s)=0` |
| Heat generation positivity | `Q > 0.3 W` at every sampled instant of discharge |
| Rest period | `Q = 0` after cutoff |
| Constituent decomposition | `Q = I^2 R(SOC) - I T dU/dT(SOC)` reproduced to 1e-12 |
| Joule energy integral | numeric `integral I^2 R dt` matches the analytic reference within 1 % |

### 2.3 Geometry tests (`tests/test_geometry.py`, 6 tests)

| check | assertion |
|-------|-----------|
| Total volume (bare) | `sum(V) = pi R^2 L` to 1e-9 relative |
| Total volume (with PCM) | `sum(V) = pi r_out^2 L`, region volumes match analytic annuli |
| Boundary face areas | barrel = `2 pi r_out L`, end caps = `2 pi r_out^2` |
| Conductance arrays | all face areas / distances finite and positive |
| Contact resistance | configured `R_c` lands exactly on the cell-PCM interface faces |
| theta-symmetry & index consistency | volumes and neighbor bookkeeping identical across sectors |

### 2.4 Solver verification (`tests/test_solver.py`, 9 tests)

These are the core physics checks.

**(a) Energy conservation -- adiabatic box test** (parametrized over all four
configurations). With every boundary flux disabled, the discretised enthalpy
scheme must satisfy `E_generated = Delta U` exactly, including the latent-heat
path:

```
bare       : |E_gen - dU|/E_gen < 1e-10   (passed at ~1e-15)
pure PW    : passed at ~1e-15
PW + 5% EG : passed at ~1e-15
hybrid     : passed at ~1e-15
```

**(b) Energy conservation with cooling.** With convection (h = 8 W/m2K) and
radiation (eps = 0.6) active, `E_gen - E_out = Delta U` still closes to
machine precision, proving boundary fluxes are booked without leaks.

**(c) Analytical steady state.** A bare cell with insulated ends, constant
`q = 1 W` and constant `h = 10 W/m2K` is compared against the classical
cylindrical solution

```
T(r) = T_amb + q''' (R^2 - r^2)/(4 k_r) + q''' R/(2 h)
```

after 15 000 s (>> 5 thermal time constants). Both the centre temperature,
the surface temperature and the centre-to-surface difference agree with the
analytical solution within 2 % / 5 %. This validates the radial
discretisation, the anisotropic-conductivity assembly, the half-cell boundary
resistance and the Robin boundary condition.

**(d) Axisymmetry.** For an axisymmetric problem the 3-D (r, theta, z) kernel
must preserve rotational symmetry: max theta-deviation of the temperature
field < 1e-6 K and of the melt-fraction field < 1e-9. This validates the
theta-direction conductance bookkeeping, including the wedge cells on the
axis.

**(e) Melt-fraction consistency.** Starting inside the mushy zone and heating
adiabatically, `f` stays in [0, 1], the latent-energy bookkeeping
`sum(f rho L V)` matches the reported value to 1e-12, and the volume-averaged
melt fraction evolves monotonically under pure heating.

**(f) Temperature bounds.** Over a full transient: outer surface >= ambient
(no unphysical cooling below ambient with no active cooling), cell max
< 120 degC, and cell surface >= outer surface (heat flows outward).

### 2.5 Convergence studies (`tests/test_grid_independence.py`, 2 tests)

**(a) Grid independence.** The pure-PW case after 1200 s of 2C discharge
(melt layer ~8 mm, thicker than the coarse cells) is run on a coarse
(8 x 5 radial, nz = 9) and a fine (16 x 10 radial, nz = 18) mesh:

| quantity | coarse | fine | difference |
|----------|--------|------|------------|
| peak cell mean T | 44.79 degC | 44.62 degC | 0.16 K (< 0.5 K required) |
| latent energy absorbed | 295.0 J | 309.5 J | 4.7 % (< 8 % required) |

*(Note: at shorter times the melt front in pure paraffin is thinner than the
coarse cells and the melt-fraction metric is genuinely resolution-dependent
-- an honest modelling observation, not a solver defect.)*

**(b) Time-step independence.** Halving `dt_max` changes the peak cell mean
temperature by < 0.1 K; the adaptive stability controller, not `dt_max`, is
the binding constraint in practice.

### 2.6 Post-processing pipeline (`tests/test_postprocess.py`, 1 test)

Runs all cases on a reduced grid end-to-end and verifies: the metrics table
columns, CSV round-trip (pandas read-back with the required columns), that
every figure file is produced, and that the markdown report renders with the
expected sections.

---

## 3. Full pytest output

```
tests/test_properties.py::test_maxwell_limits PASSED                     [  5%]
tests/test_properties.py::test_maxwell_monotonic_and_bounded PASSED      [  8%]
tests/test_properties.py::test_maxwell_symmetric_reversal PASSED         [ 10%]
tests/test_properties.py::test_nielsen_limits PASSED                     [ 13%]
tests/test_properties.py::test_nielsen_shape_enhances_for_platelets PASSED [16%]
tests/test_properties.py::test_nielsen_phi_max_guard PASSED              [ 18%]
tests/test_properties.py::test_mass_to_volume_fractions PASSED           [ 21%]
tests/test_properties.py::test_eg_composite_properties PASSED            [ 24%]
tests/test_properties.py::test_hybrid_composite_properties PASSED        [ 27%]
tests/test_properties.py::test_eg_k_interpolates_anchors PASSED          [ 29%]
tests/test_properties.py::test_unknown_type_raises PASSED                [ 32%]
tests/test_battery.py::test_current_and_duration PASSED                  [ 35%]
tests/test_battery.py::test_soc_trajectory PASSED                        [ 37%]
tests/test_battery.py::test_q_positive_during_discharge PASSED           [ 40%]
tests/test_battery.py::test_q_zero_during_rest PASSED                    [ 43%]
tests/test_battery.py::test_q_matches_constituent_terms PASSED           [ 45%]
tests/test_battery.py::test_joule_energy_integral PASSED                 [ 48%]
tests/test_battery.py::test_constant_q_override PASSED                   [ 51%]
tests/test_geometry.py::test_total_volume_bare PASSED                    [ 54%]
tests/test_geometry.py::test_total_volume_with_pcm PASSED                [ 56%]
tests/test_geometry.py::test_boundary_face_areas PASSED                  [ 59%]
tests/test_geometry.py::test_conductance_arrays_positive_finite PASSED   [ 62%]
tests/test_geometry.py::test_contact_resistance_assigned PASSED          [ 64%]
tests/test_geometry.py::test_theta_symmetry_of_volumes PASSED            [ 67%]
tests/test_geometry.py::test_neighbor_index_symmetry PASSED              [ 70%]
tests/test_grid_independence.py::test_grid_independence_pcm_case PASSED  [ 72%]
tests/test_grid_independence.py::test_time_step_independence PASSED      [ 75%]
tests/test_postprocess.py::test_full_postprocess_pipeline PASSED         [ 78%]
tests/test_solver.py::test_energy_conservation_adiabatic[none] PASSED    [ 81%]
tests/test_solver.py::test_energy_conservation_adiabatic[pure] PASSED    [ 83%]
tests/test_solver.py::test_energy_conservation_adiabatic[pw_eg] PASSED   [ 86%]
tests/test_solver.py::test_energy_conservation_adiabatic[pw_hybrid] PASSED [89%]
tests/test_solver.py::test_energy_conservation_with_cooling PASSED       [ 91%]
tests/test_solver.py::test_analytical_steady_state PASSED                [ 94%]
tests/test_solver.py::test_axisymmetry PASSED                            [ 97%]
tests/test_solver.py::test_melt_fraction_consistency PASSED              [ 97%]
tests/test_solver.py::test_temperature_bounds PASSED                     [100%]

======================== 37 passed in 140.22s ========================
```

---

## 4. Simulation-level quality evidence (production run)

Beyond the pytest suite, the production run (22 x 12 x 27 grid, 99 360
adaptive time steps per case) provides its own evidence of numerical health:

| case | steps | relative energy closure |
|------|-------|--------------------------|
| bare | 99 360 | 0.0 (machine precision) |
| pw | 99 360 | 9.7e-15 |
| pw_eg5 | 99 360 | 5.8e-16 |
| pw_hybrid | 99 360 | 3.3e-15 |

Every sampled time series row carries the running closure value
(`closure_rel` column in `results/timeseries_*.csv`), so energy conservation
can be audited continuously, not just at the end point.

## 5. Reproducing

```bash
pip install -r requirements.txt
python -m pytest tests/ -v          # verification suite (~2.5 min)
python -m btms_sim                  # production study (~5-6 min)
```
