"""Pytest bootstrap: make the project root importable and provide shared
configuration fixtures."""

import sys
from pathlib import Path

import pytest

PROJECT_ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(PROJECT_ROOT))

from btms_sim.config import apply_overrides, load_config  # noqa: E402


@pytest.fixture(scope="session")
def base_cfg() -> dict:
    """The standard configuration from config.json."""
    return load_config(PROJECT_ROOT / "config.json")


@pytest.fixture(scope="session")
def small_cfg(base_cfg: dict) -> dict:
    """Reduced grid / short horizon configuration for fast solver tests."""
    overrides = {
        "numerics": {"nr_cell": 6, "nr_pcm": 5, "n_theta": 6, "nz": 10,
                     "dt_max_s": 2.0},
        "runtime": {"discharge_s": 300.0, "rest_s": 60.0,
                    "sample_every_s": 10.0, "snapshot_times_s": [300.0]},
    }
    return apply_overrides(base_cfg, overrides)


@pytest.fixture(scope="session")
def t_eod(base_cfg: dict) -> float:
    return float(base_cfg["runtime"]["discharge_s"])
